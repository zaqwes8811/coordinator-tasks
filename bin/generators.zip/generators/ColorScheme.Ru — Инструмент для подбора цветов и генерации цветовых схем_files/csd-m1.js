var ColorSchemeDesigner = function () {
    function J(b) {
        this.ID = b;
        this.Listeners = {};
        this.addListener = function (d) {
            this.Listeners[d.ID] = d
        };
        this.removeListener = function (d) {
            delete this.Listeners[d.ID]
        };
        this.trigger = function (d, f, i) {
            var m;
            this.SysEvent = d;
            this.Data = f;
            if (i) this.Listeners[i].handleEvent(this);
            else
            for (m in this.Listeners) this.Listeners[m].handleEvent(this)
        }
    }
    function r(b) {
        this.ID = b.ID;
        this.Content = b.Content;
        this.Hooks = b.Hooks;
        this.Listeners = b.Listeners;
        this.Parent = b.Parent;
        this.UserData = b.UserData;
        this.init = function (d) {
            if (d) this.Parent = d;
            this.Parent && $(this.Parent).append(this.Content);
            this.Hooks && this.initEvents();
            this.Listeners && this.addListeners()
        };
        this.initEvents = function () {
            var d, f, i;
            d = 0;
            for (f = this.Hooks.length; d < f; d++) {
                i = this.Hooks[d];
                $(i[0]).bind(i[1], X(j[i[2]], i[3]))
            }
        };
        this.addListeners = function () {
            for (var d in this.Listeners) j[d].addListener(this)
        };
        this.removeListeners = function () {
            for (var d in this.Listeners) j[d].removeListener(this)
        };
        this.handleEvent = function (d) {
            var f = d.ID;
            if (this.Listeners[d.ID].useHandler) f = this.Listeners[d.ID].useHandler;
            this.Listeners[f].handler(d)
        }
    }
    function M(b) {
        this.CtrlList = b.CtrlList;
        this.onHandler = b.onHandler;
        this.offHandler = b.offHandler;
        this.On = true;
        this.toggle = function (d) {
            var f;
            if (this.On = d) {
                for (f in this.CtrlList) A[this.CtrlList[f]].addListeners();
                this.onHandler && this.onHandler()
            } else {
                for (f in this.CtrlList) A[this.CtrlList[f]].removeListeners();
                this.offHandler && this.offHandler()
            }
        }
    }
    function T(b) {
        return function (d) {
            d.preventDefault();
            b(d)
        }
    }
    function X(b, d) {
        return function (f) {
            f.preventDefault();
            b.trigger(f, d)
        }
    }
    function S(b) {
        if (!b) return "";
        if (b.match(/[0-9\.\+\-\*/]+/)) b = eval(b);
        return b
    }
    function P(b, d, f) {
        if ($.floatbox) {
            b = '<div id="csd3-prompt"><p>' + b + "</p>";
            b += '<p class="input"><input id="csd3-prompt-input" name="prompt-input" type="text" value="' + d + '"></p>';
            b += '<p class="submit"><button id="csd3-prompt-cancel" class="close-floatbox">Отмена</button> <button id="csd3-prompt-ok" class="close-floatbox">OK</button></p>';
            b += "</div>";
            new $.floatbox({
                content: b,
                button: "",
                fade: false,
                boxConfig: {
                    position: $.browser.msie ? "absolute" : "fixed",
                    zIndex: 999,
                    width: "360px",
                    marginLeft: "-180px",
                    height: "auto",
                    top: "33%",
                    left: "50%",
                    backgroundColor: "transparent",
                    display: "none"
                }
            });
            $("#csd3-prompt-ok").click(function () {
                f($("#csd3-prompt-input").val())
            });
            $("#csd3-prompt-input").keypress(function (i) {
                i.keyCode == 13 && $("#csd3-prompt-ok").click()
            }).focus()
        } else {
            b = prompt(b, d);
            b !== null && f(b)
        }
    }
    function B() {
        var b;
        b = (new Date).valueOf() - l.LastRefresh;
        if (b < D.MaxRedrawRate) {
            if (!l.RefreshTimerID) l.RefreshTimerID = setTimeout(U, D.MaxRedrawRate - b)
        } else U()
    }
    function U() {
        l.RefreshTimerID && clearTimeout(l.RefreshTimerID);
        l.RefreshTimerID = null;
        l.LastRefresh = (new Date).valueOf();
        var b, d, f, i, m, q, s, v, t;
        z.Colorize.find(".bg-pri").css("background-color", g.Primary.Base.RGB.getCSS());
        for (t = 0; t < 5; t++) {
            m = g.Primary.Col[t];
            v = g.Compl ? g.Compl.Col[t] : g.Primary.Col[2];
            q = g.Sec1 ? g.Sec1.Col[t] : g.Primary.Col[3];
            s = g.Sec2 ? g.Sec2.Col[t] : g.Primary.Col[4];
            b = m.RGB;
            i = v.RGB;
            d = q.RGB;
            f = s.RGB;
            if (l.CBPreview) {
                b = "#" + g.ColorBlind.getHex(b.R, b.G, b.B, l.CBPreview);
                i = "#" + g.ColorBlind.getHex(i.R, i.G, i.B, l.CBPreview);
                d = "#" + g.ColorBlind.getHex(d.R, d.G, d.B, l.CBPreview);
                f = "#" + g.ColorBlind.getHex(f.R, f.G, f.B, l.CBPreview)
            } else {
                b = b.getCSS();
                i = i.getCSS();
                d = d.getCSS();
                f = f.getCSS()
            }
            z.Colorize.find(".col-pri-" + t).css("color", b);
            z.Colorize.find(".col-compl-" + t).css("color", i);
            z.Colorize.find(".col-sec1-" + t).css("color", d);
            z.Colorize.find(".col-sec2-" + t).css("color", f);
            z.Colorize.find(".bg-pri-" + t).css("background-color", b).each(function () {
                this.paletteInfo = {
                    col: m,
                    out: b
                }
            });
            z.Colorize.find(".bg-compl-" + t).css("background-color", i).each(function () {
                this.paletteInfo = {
                    col: v,
                    out: i
                }
            });
            z.Colorize.find(".bg-sec1-" + t).css("background-color", d).each(function () {
                this.paletteInfo = {
                    col: q,
                    out: d
                }
            });
            z.Colorize.find(".bg-sec2-" + t).css("background-color", f).each(function () {
                this.paletteInfo = {
                    col: s,
                    out: f
                }
            });
            z.Colorize.find(".brd-pri-" + t).css("border-color", b);
            z.Colorize.find(".brd-compl-" + t).css("border-color", i);
            z.Colorize.find(".brd-sec1-" + t).css("border-color", d);
            z.Colorize.find(".brd-sec2-" + t).css("border-color", f)
        }
        l.SchemeID = g.serialize();
        t = l.SchemeID;
        if (t.length > 128) t = "&lt;ID too long to display&gt;";
        $("#csd3-schemeid a").html('http://ColorScheme.ru/#' + t).attr("href", document.location.pathname + "#" + l.SchemeID);


        // sl
        function sl_window(url,name,windowWidth,windowHeight)
        {
            myleft=(screen.width)?(screen.width-windowWidth)/2:100;
            mytop=(screen.height)?(screen.height-windowHeight)/2:100;
            properties = "scrollbars=0,resizable=1,menubar=0,toolbar=0,status=0,width="+windowWidth+",height="+windowHeight+", top="+mytop+",left="+myleft;
            window.open(url,name,properties);
        }

        var $sl = $('#sl');

        $sl.find('#sl-vk div').click(function() {
            sl_window("http://vkontakte.ru/share.php?url=http%3A%2F%2Fcolorscheme.ru%2F%23"+l.SchemeID, "vk", 554, 280)
        });

        $sl.find('#sl-yx div').click(function() {
            sl_window("http://wow.ya.ru/posts_share_link.xml?url=http%3A%2F%2Fcolorscheme.ru%2F%23"+l.SchemeID+"&title="+encodeURI("Подбор цветов на ColorScheme.Ru")+"&body=", "yx", 720, 430);
        });

        $sl.find('#sl-mru div').click(function() {
            sl_window("http://connect.mail.ru/share?url=http%3A%2F%2Fcolorscheme.ru%2F%23"+l.SchemeID+"&title="+encodeURI("Подбор цветов на ColorScheme.Ru"), "mru", 546, 488);
        });

        $sl.find('#sl-tw div.div').click(function() {
            sl_window("http://twitter.com/share?url=http%3A%2F%2Fcolorscheme.ru%2F%23"+l.SchemeID+"&text="+encodeURI("Инструмент для подбора цветов ColorScheme.Ru"), "tw", 632, 392);
        });

        G.On || j.chgHistory.trigger()
    }
    function V(b) {
        var d;
        if (b == 1) {
            b = "sample/index2.html";
            d = 'Светлая страница | <a href="#" id="link-sample2">Тёмная страница</a>'
        } else {
            b = "sample/index.html";
            d = '<a href="#" id="link-sample1">Светлая страница</a> | Тёмная страница'
        }
        d = '<div class="sample-info">' + d;
        if (g.Sec1) d += " \u2022 Щёлкните по странице для переключения вторичных цветов";
        d += '</div><iframe class="sample" scrolling="no" frameborder="0"></iframe>';
        new $.floatbox({
            content: d,
            button: '<button type="button" class="close-floatbox">Закрыть</button>',
            fade: false,
            boxConfig: {
                position: $.browser.msie ? "absolute" : "fixed",
                zIndex: 999,
                width: "840px",
                marginLeft: "-420px",
                height: "auto",
                top: "50%",
                left: "50%",
                backgroundColor: "transparent",
                display: "none"
            }
        });
        $("iframe.sample").attr("src", b);
        $("#link-sample1").click(function () {
            ColorSchemeDesigner.broadcast("tabPreview1Click")
        });
        $("#link-sample2").click(function () {
            ColorSchemeDesigner.broadcast("tabPreview2Click")
        })
    }
    var D = {
        MaxRedrawRate: 100,
        PaneFadeIn: 400,
        PaneFadeOut: 200,
        CanvasSelector: "#csd3-canvas"
    },
        l = {
            SchemeID: "",
            LastRefresh: 0,
            RefreshTimerID: 0,
            ManVarSelected: [0, 0],
            CBPreview: 0,
            Random: {
                Scheme: 1,
                H: 1,
                Dist: 1,
                dS: 1,
                dV: 1,
                cS: 1,
                cL: 1
            }
        },
        z = {},
        A, C, j, G, H, g;
    A = {
        ModelSelect: new r({
            ID: "ModelSelect",
            Content: null,
            Hooks: [
                ["#csd3-m1", "click", "setModel", 1],
                ["#csd3-m2", "click", "setModel", 2],
                ["#csd3-m3", "click", "setModel", 3],
                ["#csd3-m4", "click", "setModel", 4],
                ["#csd3-m5", "click", "setModel", 5],
                ["#csd3-m6", "click", "setModel", 6]
            ],
            Listeners: {
                chgModel: {
                    handler: function () {
                        var b = g.Scheme;
                        $("#csd3-model a.sel").removeClass("sel");
                        $("#csd3-" + b).addClass("sel").blur();
                        z.LivePreview.removeClass().addClass("scheme-" + b)
                    }
                }
            }
        }),
        ColorWheel: new r({
            ID: "ColorWheel",
            UserData: {
                dotSize: 7,
                wheelMid: {
                    X: 190,
                    Y: 190
                }
            },
            Content: null,
            Hooks: [
                ["#csd3-wheel", "mousedown", "dragHue"],
                ["#csd3-dot1", "mousedown", "dotClick", 1],
                ["#csd3-dot2", "mousedown", "dotClick", 2],
                ["#csd3-dot3", "mousedown", "dotClick", 3],
                ["#csd3-dot4", "mousedown", "dotClick", 4],
                ["#csd3-dot1", "dblclick", "enterHue", "pri"],
                ["#csd3-dot2", "dblclick", "enterHue", "compl"],
                ["#csd3-dot3, #csd3-dot4", "dblclick", "enterDist"]
            ],
            Listeners: {
                dragHue: {
                    handler: function (b) {
                        G.start(b, $("#csd3-wheel"), function (d, f) {
                            var i, m, q;
                            i = Math.round((Math.atan2(-d, f) * 180 / Math.PI + 180) % 360);
                            m = Math.sqrt(d * d + f * f);
                            if (m > 0 && m < 160) {
                                q = 1;
                                if (G.Data.dot) q = G.Data.dot;
                                if (q == 1 || q == 2) {
                                    if (m > 125) i = m < 135 ? Math.floor((i - 7.5) / 15 + 1) * 15 % 360 : Math.floor((i - 15) / 30 + 1) * 30 % 360;
                                    if (q == 2) i = (i + 180) % 360;
                                    j.setHue.trigger(b, i)
                                } else {
                                    if (g.Scheme == "m4" && q == 4) i = (i + 180) % 360;
                                    j.setDist.trigger(b, i)
                                }
                            }
                        }, null)
                    }
                },
                chgModel: {
                    handler: function () {
                        $("#csd3-dot2").css("display", Boolean(g.Compl) ? "block" : "none");
                        $("#csd3-dot3,#csd3-dot4").css("display", Boolean(g.Sec1) ? "block" : "none");
                        $("#csd3-dist-val").css("display", Boolean(g.Sec1) ? "block" : "none")
                    }
                },
                chgHue: {
                    handler: function () {
                        function b(f, i) {
                            if (i) {
                                var m;
                                m = (i.Col[0].HSV.H - 90) / 360 * 2 * Math.PI;
                                x = Math.round(d.wheelMid.X + 109 * Math.cos(m)) - d.dotSize;
                                y = Math.round(d.wheelMid.Y + 109 * Math.sin(m)) - d.dotSize;
                                $("#csd3-dot" + f).css("left", x + "px").css("top", y + "px")
                            }
                        }
                        var d = A.ColorWheel.UserData;
                        b(1, g.Primary);
                        b(2, g.Compl);
                        b(3, g.Sec1);
                        b(4, g.Sec2)
                    }
                },
                chgDist: {
                    handler: function (b) {
                        j.chgHue.trigger(b, null, "ColorWheel")
                    }
                }
            }
        }),
        HueVal: new r({
            ID: "HueVal",
            Content: null,
            Hooks: [
                ["#csd3-hue-val", "click", "enterHue"]
            ],
            Listeners: {
                chgHue: {
                    handler: function () {
                        $("#csd3-hue-val span").text(g.Primary.Col[0].HSV.H + "\u00b0")
                    }
                }
            }
        }),
        HueCompl: new r({
            ID: "HueCompl",
            Content: null,
            Hooks: [
                ["#csd3-hue-compl", "click", "complHue"]
            ],
            Listeners: null
        }),
        DistVal: new r({
            ID: "DistVal",
            Content: null,
            Hooks: [
                ["#csd3-dist-val", "click", "enterDist"]
            ],
            Listeners: {
                chgDist: {
                    handler: function () {
                        $("#csd3-dist-val span").text(g.Dist + "\u00b0")
                    }
                }
            }
        }),
        RGBVal: new r({
            ID: "RGBVal",
            Content: null,
            Hooks: [
                ["#csd3-rgb-val", "click", "enterRGB"]
            ],
            Listeners: {
                chgHue: {
                    handler: function () {
                        $("#csd3-rgb-val span").text(g.Primary.Col[0].RGB.getHex())
                    }
                }
            }
        }),
        RGBParts: new r({
            ID: "RGBParts",
            Content: '<table id="csd3-rgb-parts"><tr><th>R:</th><td id="csd3-rgb-r">100 %</td></tr><tr><th>G:</th><td id="csd3-rgb-g">0 %</td></tr><tr><th>B:</th><td id="csd3-rgb-b">0 %</td></tr></table>',
            Hooks: null,
            Listeners: {
                chgHue: {
                    handler: function () {
                        var b = g.Primary.Col[0].RGB;
                        $("#csd3-rgb-r").text(Math.round(b.R / 255 * 100) + " %");
                        $("#csd3-rgb-g").text(Math.round(b.G / 255 * 100) + " %");
                        $("#csd3-rgb-b").text(Math.round(b.B / 255 * 100) + " %")
                    }
                }
            }
        }),
        VarPresets: new r({
            ID: "VarPresets",
            Content: null,
            Hooks: [
                ["#csd3-presets select", "change", "presetSelect"]
            ],
            Listeners: {
                init: {
                    handler: function () {
                        var b, d, f = '<option value="">- пользовательский пресет -</option>';
                        for (b in g.Presets) {
                            d = g.Presets[b];
                            f += '<option value="' + b + '"';
                            if (b == "default") f += " selected";
                            f += ">" + d.name + "</option>"
                        }
                        $("#csd3-presets select").append(f).styledSelect()
                    }
                },
                presetSelect: {
                    handler: function (b) {
                        j.setPreset.trigger(b, $("#csd3-presets select").val());
                    }
                },
                chgSV: {
                    handler: function (b) {}
                },
                chgC: {
                    useHandler: "chgSV"
                }
            }
        }),
        SVSqrSlider: new r({
            ID: "SVSqrSlider",
            UserData: {
                dotSize: 7,
                sliderMid: {
                    X: 95,
                    Y: 95
                },
                sliderWidth: 140
            },
            Content: null,
            Hooks: [
                ["#csd3-saturation", "mousedown", "dragSV"],
                ["#csd3-dots", "mousedown", "dotClick", 1]
            ],
            Listeners: {
                dragSV: {
                    handler: function (b) {
                        G.start(b, $("#csd3-saturation"), function (d, f) {
                            var i;
                            i = A.SVSqrSlider.UserData;
                            d /= i.sliderWidth;
                            f /= i.sliderWidth;
                            if (d < -0.5) d = -0.5;
                            if (d > 0.5) d = 0.5;
                            if (f < -0.5) f = -0.5;
                            if (f > 0.5) f = 0.5;
                            i = d > 0.4 ? (d - 0.4) / 0.1 : (d + 0.5) / 0.9 - 1;
                            f = -f;
                            j.setSV.trigger(b, {
                                s: i,
                                v: f > 0.4 ? (f - 0.4) / 0.1 : (f + 0.5) / 0.9 - 1
                            })
                        }, null)
                    }
                },
                chgSV: {
                    handler: function () {
                        var b, d, f = A.SVSqrSlider.UserData;
                        b = g.dS;
                        d = g.dV;
                        b = b < 0 ? (b + 1) * 0.9 - 0.5 : 0.4 + b * 0.1;
                        d = d < 0 ? (d + 1) * 0.9 - 0.5 : 0.4 + d * 0.1;
                        (function (i, m) {
                            i = f.sliderMid.X + i * f.sliderWidth - f.dotSize + 1;
                            m = f.sliderMid.Y + m * f.sliderWidth - f.dotSize + 3;
                            $("#csd3-dots").css("left", i + "px").css("top", m + "px")
                        })(b, -d)
                    }
                },
                chgHue: {
                    handler: function () {
                        $("#csd3-saturation").css("background-color", g.Primary.Base.RGB.getCSS())
                    }
                }
            }
        }),
        CSqrSlider: new r({
            ID: "CSqrSlider",
            UserData: {
                dotSize: 7,
                sliderMid: {
                    X: 95,
                    Y: 95
                },
                sliderWidth: 140
            },
            Content: null,
            Hooks: [
                ["#csd3-contrast", "mousedown", "dragC"],
                ["#csd3-dotc", "mousedown", "dotClick", 1]
            ],
            Listeners: {
                dragC: {
                    handler: function (b) {
                        G.start(b, $("#csd3-contrast"), function (d, f) {
                            var i = A.CSqrSlider.UserData;
                            d /= i.sliderWidth;
                            f /= i.sliderWidth;
                            if (d < -0.5) d = -0.5;
                            if (d > 0.5) d = 0.5;
                            if (f < -0.5) f = -0.5;
                            if (f > 0.5) f = 0.5;
                            j.setC.trigger(b, {
                                cL: d + 0.5,
                                cS: 0.5 - f
                            })
                        }, null)
                    }
                },
                chgC: {
                    handler: function () {
                        var b = A.CSqrSlider.UserData;
                        (function (d, f) {
                            d = b.sliderMid.X + d * b.sliderWidth - b.dotSize + 1;
                            f = b.sliderMid.Y + f * b.sliderWidth - b.dotSize + 3;
                            $("#csd3-dotc").css("left", d + "px").css("top", f + "px")
                        })(g.cL - 0.5, 0.5 - g.cS)
                    }
                },
                setMVoff: {
                    useHandler: "chgC"
                }
            }
        }),
        ManVarSqrSlider: new r({
            ID: "ManVarSqrSlider",
            UserData: {
                dotSize: 7,
                sliderMid: {
                    X: 95,
                    Y: 95
                },
                sliderWidth: 140
            },
            Content: null,
            Hooks: [
                ["#csd3-manvar", "mousedown", "dragMV"],
                ["#csd3-dotv0", "mousedown", "dotClick", 0],
                ["#csd3-dotv1", "mousedown", "dotClick", 1],
                ["#csd3-dotv2", "mousedown", "dotClick", 2],
                ["#csd3-dotv3", "mousedown", "dotClick", 3],
                ["#csd3-dotv4", "mousedown", "dotClick", 4]
            ],
            Listeners: {
                chgSV: {
                    handler: function () {
                        function b(f, i, m) {
                            var q, s = '<a class="ttl" rel="' + i + '" href="#">' + m + ":</a>";
                            s += '<div class="var-set" id="csd3-var-set-' + i + '">';
                            for (m = 0; m < 5; m++) {
                                f.getVarRGB(m).getHex();
                                q = i + "-" + m;
                                s += '<a class="col" rel="' + q + '" href="#"><img src="img/e.gif" class="cbox bg-' + q + '" rel="' + q + '">';
                                s += m == 0 ? "Базовый цвет" : "Вариант " + m;
                                s += "</a>"
                            }
                            s += "</div>";
                            return s
                        }
                        var d = "";
                        d += b(g.Primary, "pri", "Основной Цвет");
                        if (g.Sec1) d += b(g.Sec1, "sec1", "Вторичный Цвет A");
                        if (g.Sec2) d += b(g.Sec2, "sec2", "Вторичный Цвет B");
                        if (g.Compl) d += b(g.Compl, "compl", "Дополнительный Цвет");
                        $("#csd3-manvar-list").html(d);
                        B();
                        $("#csd3-manvar-list a.ttl").click(function () {
                            j.selMVcol.trigger(null, $(this).attr("rel"))
                        });
                        $("#csd3-manvar-list a.col").mouseenter(function () {
                            var f = z.LivePreview.find(".bg-" + $(this).attr("rel")).addClass("hilite");
                            f.html() || f.addClass("was-empty").html('<div class="text"><span class="row1">Текст</span> <span class="row2">Текст</span> <span class="row3">Текст</span></div>')
                        }).mouseleave(function () {
                            var f = z.LivePreview.find(".bg-" + $(this).attr("rel")).removeClass("hilite");
                            f.hasClass("was-empty") && f.removeClass("was-empty").html("")
                        }).click(function () {
                            j.selMVvar.trigger(null, $(this).attr("rel"))
                        });
                        $("#csd3-manvar-list a.ttl").eq(0).click()
                    }
                },
                chgHue: {
                    useHandler: "chgSV"
                },
                selMVcol: {
                    handler: function (b) {
                        var d, f, i;
                        d = b.Data;
                        f = g.ColorHash[d];
                        i = $("#csd3-manvar-list a.ttl").filter(function () {
                            return $(this).attr("rel") == d
                        });
                        for (b = 0; b < 5; b++) {
                            l.ManVarSelected = [f, b];
                            j.chgMV.trigger()
                        }
                        $("#csd3-manvar-list .ttl.sel").removeClass("sel");
                        i.addClass("sel");
                        if (i.next(".var-set").hasClass("sel")) return false;
                        $("#csd3-manvar-list .var-set.sel").removeClass("sel").slideUp("fast");
                        i.blur().next(".var-set").addClass("sel").slideDown("fast").find("a.col").eq(0).click()
                    }
                },
                selMVvar: {
                    handler: function (b) {
                        var d;
                        d = b.Data;
                        b = $("#csd3-manvar-list a.col").filter(function () {
                            return $(this).attr("rel") == d
                        });
                        $("#csd3-manvar-list a.col.sel").removeClass("sel");
                        b.blur().addClass("sel");
                        l.ManVarSelected = d.split("-");
                        l.ManVarSelected[0] = g.ColorHash[l.ManVarSelected[0]];
                        $("#csd3-manvar").css("background-color", g.getColorByIdx(l.ManVarSelected[0]).Base.RGB.getCSS());
                        $("#csd3-manvar .dotv.sel").removeClass("sel");
                        $("#csd3-manvar #csd3-dotv" + l.ManVarSelected[1]).addClass("sel");
                        j.chgMV.trigger()
                    }
                },
                dragMV: {
                    handler: function (b) {
                        G.start(b, $("#csd3-manvar"), function (d, f) {
                            var i = A.ManVarSqrSlider.UserData;
                            d /= i.sliderWidth;
                            f /= i.sliderWidth;
                            if (d < -0.5) d = -0.5;
                            if (d > 0.5) d = 0.5;
                            if (f < -0.5) f = -0.5;
                            if (f > 0.5) f = 0.5;
                            j.setMV.trigger(b, {
                                colNr: l.ManVarSelected[0],
                                varNr: l.ManVarSelected[1],
                                s: d + 0.5,
                                v: -f + 0.5
                            })
                        }, null)
                    }
                },
                chgMV: {
                    handler: function () {
                        var b, d, f = A.ManVarSqrSlider.UserData;
                        b = g.getVarOverlay(l.ManVarSelected[0], l.ManVarSelected[1]);
                        d = b[0] - 0.5;
                        y = 0.5 - b[1];
                        d = f.sliderMid.X + d * f.sliderWidth - f.dotSize + 1;
                        y = f.sliderMid.Y + y * f.sliderWidth - f.dotSize + 3;
                        $("#csd3-dotv" + l.ManVarSelected[1]).css("left", d + "px").css("top", y + "px")
                    }
                }
            }
        }),
        SchemeInfo: new r({
            ID: "SchemeInfo",
            Content: '<div id="csd3-coltable"></div>',
            Hooks: null,
            Listeners: {
                chgPalette: {
                    handler: function () {
                        function b(f, i, m) {
                            var q, s, v = "<h4>" + m + ":</h4>",
                                t = "",
                                N = "",
                                w = {};
                            for (m = 0; m < 5; m++) {
                                q = f.getVarRGB(m);
                                s = q.getName();
                                q = q.getHex();
                                if (!w[q]) {
                                    w[q] = true;
                                    s = s.length ? s.join("<br>") + "<br>(" + q + ")" : q;
                                    t += '<td class="cbox bg-' + i + "-" + m + '"></td>';
                                    N += '<td class="code">' + s + "</td>"
                                }
                            }
                            v += '<table class="info-table"><tr>' + t + "</tr><tr>" + N + "</tr></table>";
                            return v
                        }
                        var d = "";
                        d += b(g.Primary, "pri", "Основной Цвет");
                        if (g.Sec1) d += b(g.Sec1, "sec1", "Вторичный Цвет A");
                        if (g.Sec2) d += b(g.Sec2, "sec2", "Вторичный Цвет B");
                        if (g.Compl) d += b(g.Compl, "compl", "Дополнительный Цвет");
                        if (g.Conversion == 2) d += '<p class="info">Соответствие цветов только приблизительное. \u00a9\u00a0Pantone, Inc. All rights reserved.</p>';
                        else if (g.Conversion == 3) d += '<p class="info">Соответствие цветов только приблизительное. \u00a9\u00a0RAL GmbH. All rights reserved.</p>';
                        $("#csd3-coltable").html(d);
                        B()
                    }
                }
            }
        }),
        TabWheel: new r({
            ID: "TabWheel",
            Content: null,
            Hooks: [
                ["#csd3-tab-wheel", "click", "tabWheelClick"]
            ],
            Listeners: {
                tabWheelClick: {
                    handler: function () {
                        C.paneWheel.toggle(1);
                        C.paneVars.toggle(0);
                        C.paneInfo.toggle(0);
                        j.chgModel.trigger();
                        j.chgHue.trigger();
                        j.chgDist.trigger();
                        B()
                    }
                }
            }
        }),
        TabVars: new r({
            ID: "TABVars",
            Content: null,
            Hooks: [
                ["#csd3-tab-vars", "click", "tabVarsClick"]
            ],
            Listeners: {
                tabVarsClick: {
                    handler: function () {
                        C.paneWheel.toggle(0);
                        C.paneVars.toggle(1);
                        C.paneInfo.toggle(0);
                        j.chgHue.trigger();
                        j.chgSV.trigger();
                        j.chgC.trigger();
                        B()
                    }
                }
            }
        }),
        TabInfo: new r({
            ID: "TabInfo",
            Content: null,
            Hooks: [
                ["#csd3-tab-info", "click", "tabInfoClick"]
            ],
            Listeners: {
                tabInfoClick: {
                    handler: function () {
                        C.paneWheel.toggle(0);
                        C.paneVars.toggle(0);
                        C.paneInfo.toggle(1);
                        j.chgPalette.trigger()
                    }
                }
            }
        }),
        TabPreview0: new r({
            ID: "TabPreview0",
            Content: null,
            Hooks: [
                ["#csd3-showtext-btn", "click", "PreviewTextToggle"]
            ],
            Listeners: {
                PreviewTextToggle: {
                    handler: function () {
                        var b, d = $("#csd3-showtext-btn");
                        if (d.hasClass("sel")) {
                            b = "";
                            d.removeClass("sel").html("Показать образец текста")
                        } else {
                            b = '<div class="text"><span class="row1">Текст</span> <span class="row2">Текст</span> <span class="row3">Текст</span></div>';
                            d.addClass("sel").html("Скрыть образец текста")
                        }
                        $("#csd3-preview-palette td").html(b)
                    }
                }
            }
        }),
        TabPreview1: new r({
            ID: "TabPreview1",
            Content: null,
            Hooks: [
                ["#csd3-tab-preview1", "click", "tabPreview1Click"]
            ],
            Listeners: {
                tabPreview1Click: {
                    handler: function () {
                        V(1)
                    }
                }
            }
        }),
        TabPreview2: new r({
            ID: "TabPreview2",
            Content: null,
            Hooks: [
                ["#csd3-tab-preview2", "click", "tabPreview2Click"]
            ],
            Listeners: {
                tabPreview2Click: {
                    handler: function () {
                        V(2)
                    }
                }
            }
        }),
        TabC1: new r({
            ID: "TabC1",
            Content: null,
            Hooks: [
                ["#csd3-tab-c1", "click", "setMVoff"]
            ],
            Listeners: {
                setMVoff: {
                    handler: function () {
                        C.paneC1.toggle(1);
                        C.paneC2.toggle(0);
                        j.resetMV.trigger();
                        j.chgHue.trigger();
                        j.chgSV.trigger()
                    }
                }
            }
        }),
        TabC2: new r({
            ID: "TabC2",
            Content: null,
            Hooks: [
                ["#csd3-tab-c2", "click", "setMVon"]
            ],
            Listeners: {
                setMVon: {
                    handler: function () {
                        C.paneC1.toggle(0);
                        C.paneC2.toggle(1);
                        j.chgHue.trigger()
                    }
                }
            }
        }),
        MenuHistory: new r({
            ID: "MenuHistory",
            Content: null,
            Hooks: null,
            Listeners: {
                init: {
                    handler: function () {
                        $("#csd3-menu-undo,#csd3-menu-redo").addClass("disabled")
                    }
                },
                historyUpdated: {
                    handler: function () {
                        H.isFirst() ? $("#csd3-menu-undo").addClass("disabled") : $("#csd3-menu-undo").removeClass("disabled");
                        H.isLast() ? $("#csd3-menu-redo").addClass("disabled") : $("#csd3-menu-redo").removeClass("disabled")
                    }
                }
            }
        }),
        MenuVision: new r({
            ID: "MenuVision",
            Content: null,
            Hooks: null,
            Listeners: {
                init: {
                    handler: function () {
                        var b, d, f = "";
                        b = 0;
                        for (d = g.ColorBlind.typeDesc.length; b < d; b++) {
                            p = g.ColorBlind.typeDesc[b];
                            f += '<li><a class="vision-cb' + b + '" href="#" rel="' + b + '">' + p + "</a></li>";
                            if (b == 0) f += '<li class="sep"><hr></li>'
                        }
                        $("#csd3-submenu-vision").html(f);
                        $("#csd3-submenu-vision li a").click(function () {
                            j.setVision.trigger(null, $(this).attr("rel"))
                        });
                        j.setVision.trigger(null, 0)
                    }
                }
            }
        }),
        VisionWarning: new r({
            ID: "VisionWarning",
            Content: null,
            Hooks: null,
            Listeners: {
                chgVision: {
                    handler: function () {
                        var b = l.CBPreview > 0 || g.Conversion > 0;
                        $("#csd3-vision-warning").toggle(b)
                    }
                }
            }
        }),
        Tooltips: new r({
            ID: "Tooltips",
            UserData: {
                disabled: false,
                active: false
            },
            Content: "",
            Hooks: null,
            Listeners: {
                init: {
                    handler: function () {
                        if (!ColorSchemeDesignerTooltips) {
                            $("#csd3-menu-tooltips").addClass("disabled");
                            A.Tooltips.UserData.disabled = true
                        }
                    }
                },
                toggleTooltips: {
                    handler: function () {
                        var b = A.Tooltips.UserData;
                        if (!b.disabled) if (b.active) {
                            $("#csd3-menu-help, #csd3-menu-tooltips").removeClass("sel");
                            $(".has-tooltip").removeClass("has-tooltip").tooltipOff();
                            b.active = false
                        } else {
                            $("#csd3-menu-help, #csd3-menu-tooltips").addClass("sel");
                            b.active = true;
                            for (var d in ColorSchemeDesignerTooltips) $("#" + d).addClass("has-tooltip").tooltip({
                                bodyHandler: function () {
                                    return ColorSchemeDesignerTooltips[$(this).attr("id")]
                                },
                                id: "csd3-tooltip",
                                showURL: false,
                                delay: 500,
                                fade: 100,
                                track: true,
                                left: -50
                            })
                        }
                    }
                }
            }
        }),
        ColorTooltips: new r({
            ID: "ColorTooltips",
            Content: "",
            Hooks: null,
            Listeners: {
                init: {
                    handler: function () {
                        $(".cbox").tooltip({
                            bodyHandler: function () {
                                var b = this.paletteInfo.out,
                                    d = "#" + this.paletteInfo.col.RGB.getHex();
                                if (l.CBPreview) d += "<br>(как " + b + ")";
                                return d
                            },
                            id: "csd3-tooltip",
                            showURL: false,
                            delay: 0,
                            fade: 0,
                            track: true,
                            extraClass: "color",
                            top: 15,
                            left: 10
                        })
                    }
                },
                chgHistory: {
                    useHandler: "init"
                }
            }
        })
    };
    C = {
        paneWheel: new M({
            CtrlList: ["ColorWheel", "HueVal", "HueCompl", "DistVal", "RGBVal", "RGBParts"],
            onHandler: function () {
                $("#csd3-pane-wheel").fadeIn(D.PaneFadeIn);
                $("#csd3-tab-wheel").addClass("sel").blur()
            },
            offHandler: function () {
                $("#csd3-pane-wheel").fadeOut(D.PaneFadeOut);
                $("#csd3-tab-wheel").removeClass("sel")
            }
        }),
        paneVars: new M({
            CtrlList: ["VarPresets", "SVSqrSlider", "CSqrSlider"],
            onHandler: function () {
                $("#csd3-pane-vars").fadeIn(D.PaneFadeIn);
                $("#csd3-tab-vars").addClass("sel").blur();
                $("#csd3-presets select").trigger("resize")
            },
            offHandler: function () {
                $("#csd3-pane-vars").fadeOut(D.PaneFadeOut);
                $("#csd3-tab-vars").removeClass("sel")
            }
        }),
        paneInfo: new M({
            CtrlList: ["SchemeInfo"],
            onHandler: function () {
                $("#csd3-pane-info").fadeIn(D.PaneFadeIn);
                $("#csd3-tab-info").addClass("sel").blur()
            },
            offHandler: function () {
                $("#csd3-pane-info").fadeOut(D.PaneFadeOut);
                $("#csd3-tab-info").removeClass("sel")
            }
        }),
        paneC1: new M({
            CtrlList: ["SVSqrSlider", "CSqrSlider"],
            onHandler: function () {
                $("#csd3-c1-cover").fadeIn(D.PaneFadeIn);
                $("#csd3-tab-c1").addClass("sel").blur()
            },
            offHandler: function () {
                $("#csd3-c1-cover").fadeOut(D.PaneFadeOut);
                $("#csd3-tab-c1").removeClass("sel")
            }
        }),
        paneC2: new M({
            CtrlList: ["ManVarSqrSlider"],
            onHandler: function () {
                $("#csd3-c2-cover").fadeIn(D.PaneFadeIn);
                $("#csd3-tab-c2").addClass("sel").blur()
            },
            offHandler: function () {
                $("#csd3-c2-cover").fadeOut(D.PaneFadeOut);
                $("#csd3-tab-c2").removeClass("sel")
            }
        })
    };
    A.Core = new r({
        ID: "Core",
        Content: null,
        Hooks: null,
        Listeners: {
            loadSchemeByURL: {
                handler: function () {
                    j.historyReset.trigger();
                    var b = document.location.hash.substring(1);
                    b ? j.loadScheme.trigger(null, {
                        SchemeID: b
                    }) : j.chgAll.trigger()
                }
            },
            loadScheme: {
                handler: function (b) {
                    b.Data.LockHistory && H.lock();
                    g.unserialize(b.Data.SchemeID);
                    j.chgAll.trigger();
                    b.Data.LockHistory && H.unlock()
                }
            },
            randomScheme: {
                handler: function () {
                    g.setAll({
                        Scheme: l.Random.Scheme ? "m" + Math.ceil(Math.random() * 6) : g.Scheme,
                        Conversion: g.Conversion,
                        H: l.Random.H ? Math.floor(Math.random() * 360) : g.H,
                        Dist: l.Random.Dist ? g.SchemeModel.minD + Math.round(Math.random() * (g.SchemeModel.maxD - g.SchemeModel.minD)) : g.Dist,
                        dS: l.Random.dS ? -1 + Math.random() * 2 : g.dS,
                        dV: l.Random.dV ? -1 + Math.random() * 2 : g.dV,
                        cS: l.Random.cS ? Math.random() : g.cS,
                        cL: l.Random.cL ? Math.random() : g.cL
                    });
                    j.chgAll.trigger()
                }
            },
            chgAll: {
                handler: function () {
                    j.chgModel.trigger();
                    j.chgHue.trigger();
                    j.chgDist.trigger();
                    g.UseVarsOverlay ? j.setMVon.trigger() : j.setMVoff.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setModel: {
                handler: function (b) {
                    g.setScheme("m" + b.Data);
                    j.chgModel.trigger();
                    j.chgHue.trigger();
                    j.chgDist.trigger();
                    j.setMVoff.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setHue: {
                handler: function (b) {
                    g.setHue(b.Data);
                    j.chgHue.trigger();
                    j.setMVoff.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setHex: {
                handler: function (b) {
                    g.setHex(b.Data);
                    j.chgHue.trigger();
                    j.setMVoff.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setDist: {
                handler: function (b) {
                    g.setDist(b.Data);
                    j.chgDist.trigger();
                    j.setMVoff.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setDistNum: {
                handler: function (b) {
                    g.setDistNum(b.Data);
                    j.chgDist.trigger();
                    j.setMVoff.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setPreset: {
                handler: function (b) {
                    if (b.Data) {
                        g.usePreset(b.Data);
                        j.chgPalette.trigger();
                        j.setMVoff.trigger();
                        j.chgSV.trigger(b, "preset");
                        j.chgC.trigger(b, "preset");
                        B()
                    }
                }
            },
            setSV: {
                handler: function (b) {
                    g.setSV(b.Data.s, b.Data.v);
                    j.chgSV.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setC: {
                handler: function (b) {
                    g.setContrast(b.Data.cS, b.Data.cL);
                    j.chgC.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            setMV: {
                handler: function (b) {
                    g.setVarOverlay(b.Data.colNr, b.Data.varNr, b.Data.s, b.Data.v);
                    j.chgMV.trigger();
                    j.chgPalette.trigger();
                    B()
                }
            },
            resetMV: {
                handler: function () {
                    g.resetVarsOverlay();
                    j.chgPalette.trigger();
                    B()
                }
            },
            enterHue: {
                handler: function (b) {
                    var d;
                    b.Data == "compl" ? P("Введите оттенок комплемента (0\u00b0\u2013360\u00b0)", (g.H + 180) % 360, function (f) {
                        d = parseInt(S(f), 10) % 360;
                        d >= 0 && d <= 360 && j.setHue.trigger(null, (d + 180) % 360)
                    }) : P("Введите оттенок (0\u00b0\u2013360\u00b0)", g.H, function (f) {
                        d = parseInt(S(f), 10) % 360;
                        d >= 0 && d <= 360 && j.setHue.trigger(null, d % 360)
                    })
                }
            },
            complHue: {
                handler: function () {
                    j.setHue.trigger(null, (g.H + 180) % 360)
                }
            },
            enterDist: {
                handler: function () {
                    var b, d = g.SchemeModel.minD,
                        f = g.SchemeModel.maxD;
                    P("Введите Дистанцию/Угол (" + d + "\u00b0\u2013" + f + "\u00b0)", g.Dist, function (i) {
                        b = Math.abs(parseInt(S(i), 10));
                        b >= d && b <= f && j.setDistNum.trigger(null, b)
                    })
                }
            },
            enterRGB: {
                handler: function () {
                    P("Введите значение RGB (000000\u2013FFFFFF)", g.Primary.getVarRGB(0).getHex(), function (b) {
                        b && b.match(/^\s*[0-9a-fA-F]{6}\s*$/) && j.setHex.trigger(null, b)
                    })
                }
            },
            randomPrefs: {
                handler: function () {
                    function b(f, i, m) {
                        return '<p class="input chkbox"><input id="csd3-' + f + '" type="checkbox"' + (m ? " checked" : "") + '> <label for="' + f + '">' + i + "</label></p>"
                    }
                    var d;
                    d = '<div id="csd3-prompt"><h4>Параметры Рандомизации:</h4>';
                    d += b("rnd-scheme", "Модель цветовой схемы", l.Random.Scheme);
                    d += b("rnd-h", "Оттенок", l.Random.H);
                    d += b("rnd-d", "Угол/Дистанция", l.Random.Dist);
                    d += b("rnd-ds", "Насыщенность", l.Random.dS);
                    d += b("rnd-dv", "Яркость", l.Random.dV);
                    d += b("rnd-cs", "Контраст (Тень)", l.Random.cS);
                    d += b("rnd-cl", "Контраст (Свет)", l.Random.cL);
                    d += '<p class="submit"><button id="csd3-prompt-cancel" class="close-floatbox">Отмена</button> <button id="csd3-prompt-ok" class="close-floatbox">OK</button></p>';
                    d += "</div>";
                    new $.floatbox({
                        content: d,
                        button: "",
                        fade: false,
                        boxConfig: {
                            position: $.browser.msie ? "absolute" : "fixed",
                            zIndex: 999,
                            width: "360px",
                            marginLeft: "-180px",
                            height: "auto",
                            top: "33%",
                            left: "50%",
                            backgroundColor: "transparent",
                            display: "none"
                        }
                    });
                    $("#csd3-prompt-ok").click(function () {
                        l.Random.Scheme = $("#csd3-rnd-scheme:checked").length;
                        l.Random.H = $("#csd3-rnd-h:checked").length;
                        l.Random.Dist = $("#csd3-rnd-d:checked").length;
                        l.Random.dS = $("#csd3-rnd-ds:checked").length;
                        l.Random.dV = $("#csd3-rnd-dv:checked").length;
                        l.Random.cS = $("#csd3-rnd-cs:checked").length;
                        l.Random.cL = $("#csd3-rnd-cl:checked").length
                    });
                    $("#csd3-prompt-input").keypress(function (f) {
                        f.keyCode == 13 && $("#csd3-prompt-ok").click()
                    }).focus().select()
                }
            },
            dotClick: {
                handler: function (b) {
                    G.Data.dot = b.Data
                }
            },
            dotRelease: {
                handler: function () {
                    G.Data.dot = null
                }
            },
            setVision: {
                handler: function (b) {
                    l.CBPreview = parseInt(b.Data, 10);
                    $("#csd3-menu-vision").toggleClass("sel", l.CBPreview > 0);
                    $("#csd3-submenu-vision a.sel").removeClass("sel");
                    $("#csd3-submenu-vision a.vision-cb" + l.CBPreview).addClass("sel");
                    j.chgVision.trigger();
                    B()
                }
            },
            setConversion: {
                handler: function (b) {
                    b = b.Data;
                    $("#csd3-menu-convert").toggleClass("sel", b > 0);
                    $("#csd3-submenu-convert a.sel").removeClass("sel");
                    $("#csd3-menu-convert-" + b).addClass("sel");
                    g.setConversion(b);
                    j.chgAll.trigger();
                    j.chgVision.trigger();
                    B()
                }
            },
            setExport: {
                handler: function (b) {
                    function d(f, i, m) {
                        var q, s, v;
                        m = '"' + i + '":{"ttl":"' + m + '","col":[';
                        for (i = 0; i < 5; i++) {
                            q = f.getVarRGB(i);
                            s = q.getHex();
                            v = q.getName();
                            if (i > 0) m += ",";
                            m += '{"hex":"' + s + '","r":' + q.R + ',"g":' + q.G + ',"b":' + q.B + ',"name":[';
                            if (v.length) m += '"' + v.join('","') + '"';
                            m += "]}"
                        }
                        m += "]}";
                        return m
                    }
                    b = '{"type":"' + b.Data + '","id":"' + l.SchemeID + '","colorspace":"' + ["RGB", "RGB (Web Safe Colors)", "Pantone (TM) Colors", "RAL (TM) Colors"][g.Conversion] + '","colorspaceinfo":"' + ["", "RGB color space reduced to 216 web safe color set", "Copyright (c) Pantone, Inc. All rights reserved. The color match is only aproximative, you get just an impression of what the Pantone colors could look like. Pantone guide is the only reliable source to see the colors.", "Copyright (c) RAL GmbH. All rights reserved. The color match is only aproximative. Use the real RAL color cards and collections to see the colors."][g.Conversion] + '","scheme":{';
                    b += d(g.Primary, "primary", "Основной Цвет");
                    if (g.Sec1) b += "," + d(g.Sec1, "secondary-a", "Вторичный Цвет A");
                    if (g.Sec2) b += "," + d(g.Sec2, "secondary-b", "Вторичный Цвет B");
                    if (g.Compl) b += "," + d(g.Compl, "complement", "Дополнительный Цвет");
                    b += "}}";
                    $("#csd3-form").attr("action", "/export/").attr("method", "POST").attr("target", "_blank");
                    $("#csd3-form-data").val(b);
                    $("#csd3-form").submit()
                }
            }
        }
    });
    A.History = new r({
        ID: "History",
        Content: null,
        Hooks: null,
        Listeners: {
            chgHistory: {
                handler: function () {
                    H.add()
                }
            },
            historyBack: {
                handler: function () {
                    H.back()
                }
            },
            historyFwd: {
                handler: function () {
                    H.fwd()
                }
            },
            historyReset: {
                handler: function () {
                    H.reset()
                }
            }
        }
    });
    j = function () {
        var b, d, f = {},
            i = ["init", "loadSchemeByURL", "loadScheme", "randomScheme", "setModel", "setHue", "setHex", "setDist", "setDistNum", "setPreset", "setSV", "setC", "setMV", "resetMV", "selMVcol", "selMVvar", "dragHue", "dragSV", "dragMV", "dragC", "dotClick", "dotRelease", "tabWheelClick", "tabVarsClick", "tabInfoClick", "setMVoff", "setMVon", "presetSelect", "tabPreview0Click", "tabPreview1Click", "tabPreview2Click", "PreviewTextToggle", "enterHue", "complHue", "enterDist", "enterRGB", "randomPrefs", "chgAll", "chgModel", "chgHue", "chgDist", "chgSV", "chgC", "chgMV", "chgPalette", "chgHistory", "historyBack", "historyFwd", "historyUpdated", "historyReset", "setVision", "chgVision", "setConversion", "setExport", "toggleTooltips"];
        b = 0;
        for (d = i.length; b < d; b++) f[i[b]] = new J(i[b]);
        return f
    }();
    G = new

    function () {
        this.reset = function () {
            this.On = false;
            this.Origin = {};
            this.handlers = {};
            this.$elm = null;
            this.Data = {}
        };
        this.start = function (b, d, f, i) {
            this.On = true;
            this.$elm = d;
            this.handlers.onMove = f;
            this.handlers.onEnd = i;
            f = d.offset();
            this.Origin.dW = d.width();
            this.Origin.dH = d.height();
            this.Origin.dX = f.left + this.Origin.dW / 2;
            this.Origin.dY = f.top + this.Origin.dH / 2;
            this.$elm.bind("mousemove", T(this.move));
            this.$elm.bind("mouseup", T(this.end));
            this.move(b.SysEvent)
        };
        this.move = function (b) {
            var d;
            d = b.pageX - _this.Origin.dX;
            b = b.pageY - _this.Origin.dY;
            _this.handlers.onMove && _this.handlers.onMove(d, b)
        };
        this.end = function () {
            _this.$elm.unbind("mousemove");
            _this.$elm.unbind("mouseup");
            _this.handlers.onEnd && _this.handlers.onEnd();
            _this.reset();
            j.chgHistory.trigger()
        };
        _this = this;
        this.reset()
    };
    H = {
        List: [],
        Ptr: -1,
        Lock: false,
        reset: function () {
            this.List = [];
            this.Ptr = -1
        },
        add: function () {
            if (!this.Lock && (this.Ptr < 0 || this.List[this.Ptr] != l.SchemeID)) {
                if (this.List.length > this.Ptr + 1) this.List = this.List.splice(0, this.Ptr + 1);
                this.List.push(l.SchemeID);
                this.Ptr++;
                j.historyUpdated.trigger()
            }
        },
        back: function () {
            if (!(this.Ptr < 1)) {
                this.Ptr--;
                j.loadScheme.trigger(null, {
                    SchemeID: this.List[this.Ptr],
                    LockHistory: true
                });
                j.historyUpdated.trigger()
            }
        },
        fwd: function () {
            if (!(this.Ptr >= this.List.length - 1)) {
                this.Ptr++;
                j.loadScheme.trigger(null, {
                    SchemeID: this.List[this.Ptr],
                    LockHistory: true
                });
                j.historyUpdated.trigger()
            }
        },
        lock: function () {
            this.Lock = true
        },
        unlock: function () {
            this.Lock = false
        },
        isFirst: function () {
            return this.Ptr == 0
        },
        isLast: function () {
            return this.Ptr == this.List.length - 1
        }
    };
    H.reset();
    g = new

    function () {
        function b(a, c) {
            c || (c = 2);
            for (var e = a.toString(16); e.length < c;) e = "0" + e;
            return e.toUpperCase()
        }
        function d(a) {
            return parseInt(a, 16)
        }
        function f(a) {
            if (a && a.match(/^\s*[0-9a-fA-F]{6}\s*$/)) {
                var c, e;
                c = d(a.substring(0, 2));
                e = d(a.substring(2, 4));
                a = d(a.substring(4, 6));
                return new v(c, e, a)
            } else
            return false
        }
        function i(a, c) {
            if (c - a > 180) a += 360;
            else if (a - c > 180) c += 360;
            return c - a
        }
        function m(a, c, e) {
            return e == -1 ? a : a + (c - a) / (1 + e)
        }
        function q(a, c, e) {
            return e == -1 ? c : c + (a - c) / (1 + e)
        }
        function s(a, c, e) {
            this.set = function (h, k, o) {
                this.H = h;
                this.S = k;
                this.V = o
            };
            this.copy = function () {
                return new s(this.H, this.S, this.V)
            };
            this.set(a, c, e)
        }
        function v(a, c, e) {
            this.set = function (h, k, o) {
                this.R = Math.round(h);
                this.G = Math.round(k);
                this.B = Math.round(o)
            };
            this.copy = function () {
                return new v(this.R, this.G, this.B)
            };
            this.toWebCol = function () {
                this.R = Math.round(this.R / 51) * 51;
                this.G = Math.round(this.G / 51) * 51;
                this.B = Math.round(this.B / 51) * 51
            };
            this.toPantone = function () {
                var h = g.Pantone.search(this);
                if (h) {
                    this.R = h.RGB.R;
                    this.G = h.RGB.G;
                    this.B = h.RGB.B;
                    this.Name = [h.Name]
                }
            };
            this.toRAL = function () {
                var h = g.RAL.search(this);
                if (h) {
                    this.R = h.RGB.R;
                    this.G = h.RGB.G;
                    this.B = h.RGB.B;
                    this.Name = [h.Name, h.Name2]
                }
            };
            this.getCSS = function () {
                return "rgb(" + this.R + "," + this.G + "," + this.B + ")"
            };
            this.getHex = function () {
                return b(this.R) + b(this.G) + b(this.B)
            };
            this.getName = function () {
                return this.Name || []
            };
            this.set(a, c, e)
        }
        function t(a, c, e, h, k, o) {
            this.getVariant = function (n, u, F) {
                n = new s(n.H, u <= 0 ? n.S * (u + 1) : n.S + (1 - n.S) * u, F <= 0 ? n.V * (F + 1) : n.V + (1 - n.V) * F);
                u = I.getRGB(n.H, n.S, n.V);
                if (o == 1) u.toWebCol();
                else if (o == 2) u.toPantone();
                else o == 3 && u.toRAL();
                return {
                    HSV: n,
                    RGB: u
                }
            };
            this.getOverlayVariant = function (n, u, F) {
                n = new s(n.H, u, F);
                u = I.getRGB(n.H, n.S, n.V);
                if (o == 1) u.toWebCol();
                else if (o == 2) u.toPantone();
                else o == 3 && u.toRAL();
                return {
                    HSV: n,
                    RGB: u
                }
            };
            this.getVarHSV = function (n) {
                return this.Col[n].HSV
            };
            this.getVarRGB = function (n) {
                return this.Col[n].RGB
            };
            this.H = a;
            this.Base = I.getBaseColorByHue(a);
            this.Col0 = this.getVariant(this.Base.HSV, c, e, o);
            this.Col = [];
            k[0] ? this.Col.push(this.getOverlayVariant(this.Base.HSV, k[0][0], k[0][1], o)) : this.Col.push(this.Col0);
            a = 0;
            for (c = h.length; a < c; a++) this.Col[a + 1] = k[a + 1] ? this.getOverlayVariant(this.Base.HSV, k[a + 1][0], k[a + 1][1], o) : this.getVariant(this.Col0.HSV, h[a].dS, h[a].dV, o)
        }
        function N(a) {
            this.SourceData = a;
            this.Data = {};
            this.Hues = null;
            this.Inited = false;
            this.init = function () {
                this.Inited = true
            };
            this.indexByHue = function (c) {
                var e;
                if (!this.Hues) {
                    this.Hues = {};
                    for (e = 0; e < 360; e += 30) this.Hues[e] = []
                }
                this.Hues[Math.floor(this.Data[c].HSV.H / 30) * 30].push(c)
            };
            this.search = function (c) {
                this.Inited || this.init();
                var e = b(c.R) + b(c.G) + b(c.B);
                if (this.Cache[e]) return this.Cache[e];
                var h, k, o, n, u, F, K = 1E3,
                    L;
                o = I.getColorByRGB(c);
                h = Math.floor(o.H / 30) * 30;
                o = $.merge([], this.Hues[h]);
                o = $.merge(o, this.Hues[(h - 30 + 360) % 360]);
                o = $.merge(o, this.Hues[(h + 30) % 360]);
                h = 0;
                for (k = o.length; h < k; h++) {
                    n = this.Data[o[h]].RGB;
                    u = n.R - c.R;
                    F = n.B - c.B;
                    n = n.G - c.G;
                    u = Math.sqrt(u * u + n * n + F * F);
                    if (u < K) {
                        K = u;
                        L = o[h]
                    }
                    if (K == 0) break
                }
                this.cache(e, L);
                return this.Data[L]
            };
            this.Cache = {
                Items: {},
                Idx: [],
                MaxSize: 127,
                FreeBy: 32
            };
            this.cache = function (c, e) {
                this.Cache.Items[c] = this.Data[e];
                this.Cache.Idx.push(c);
                if (this.Cache.Idx.length > this.Cache.MaxSize) {
                    for (var h = 0; h < this.Cache.FreeBy; h++) delete this.Cache.Items[this.Cache.Idx[h]];
                    this.Cache.Idx = this.Cache.Idx.slice(this.Cache.FreeBy)
                }
            }
        }
        var w, E, I, O, Q;
        w = {
            _key: "0123456789abcdefghijklmnopqrstuvwxyz.ABCDEFGHIJKLMNOPQRSTUVWXYZ-",
            _pad: "0000000000000000",
            encodeInt: function (a, c) {
                var e = "",
                    h, k = a;
                for (a || (e = "0"); k;) {
                    h = k & 63;
                    e = this._key.charAt(h) + e;
                    k >>= 6
                }
                if (c) {
                    e = this._pad + e;
                    e = e.substring(e.length - c)
                }
                return e
            },
            decodeInt: function (a) {
                var c, e, h, k = 0;
                if (!a) return 0;
                e = 0;
                for (h = a.length; e < h; e++) {
                    k <<= 6;
                    c = this._key.indexOf(a.charAt(e));
                    k |= c
                }
                return k
            },
            encodeFloat: function (a, c) {
                c || (c = 1);
                return this.encodeInt(Math.round((Math.pow(64, c) - 1) * a), c)
            },
            decodeFloat: function (a, c, e) {
                a = this.decodeInt(a);
                if (!a) return 0;
                c = a / (Math.pow(64, c) - 1);
                if (e) {
                    e = Math.pow(10, e);
                    c = Math.round(c * e) / e
                }
                return c
            }
        };
        E = {
            R: {
                RGB: new v(255, 0, 0),
                HSV: new s(0, 1, 1)
            },
            RG: {
                RGB: new v(255, 255, 0),
                HSV: new s(120, 1, 1)
            },
            G: {
                RGB: new v(0, 255, 0),
                HSV: new s(180, 1, 0.8)
            },
            GB: {
                RGB: new v(0, 255, 255),
                HSV: new s(210, 1, 0.6)
            },
            B: {
                RGB: new v(0, 0, 255),
                HSV: new s(255, 0.85, 0.7)
            },
            BR: {
                RGB: new v(255, 0, 255),
                HSV: new s(315, 1, 0.65)
            }
        };
        I = {
            getArc: function (a) {
                if (a < 120) return this.RRG;
                if (a < 180) return this.RGG;
                if (a < 210) return this.GGB;
                if (a < 255) return this.GBB;
                if (a < 315) return this.BBR;
                return this.BRR
            },
            RRG: {
                a: E.R,
                b: E.RG,
                f: function (a) {
                    if (a == 0) return -1;
                    return Math.tan((120 - a) / 120 * Math.PI / 2) * 0.5
                },
                fi: function (a) {
                    if (a == -1) return 0;
                    return 120 - Math.atan(a / 0.5) * 120 / Math.PI * 2
                },
                g: m,
                orderRGB: function (a, c, e) {
                    return new v(a, c, e)
                }
            },
            RGG: {
                a: E.RG,
                b: E.G,
                f: function (a) {
                    if (a == 180) return -1;
                    return Math.tan((a - 120) / 60 * Math.PI / 2) * 0.5
                },
                fi: function (a) {
                    if (a == -1) return 180;
                    return 120 + Math.atan(a / 0.5) * 60 / Math.PI * 2
                },
                g: q,
                orderRGB: function (a, c, e) {
                    return new v(c, a, e)
                }
            },
            GGB: {
                a: E.G,
                b: E.GB,
                f: function (a) {
                    if (a == 180) return -1;
                    return Math.tan((210 - a) / 30 * Math.PI / 2) * 0.75
                },
                fi: function (a) {
                    if (a == -1) return 180;
                    return 210 - Math.atan(a / 0.75) * 30 / Math.PI * 2
                },
                g: m,
                orderRGB: function (a, c, e) {
                    return new v(e, a, c)
                }
            },
            GBB: {
                a: E.GB,
                b: E.B,
                f: function (a) {
                    if (a == 255) return -1;
                    return Math.tan((a - 210) / 45 * Math.PI / 2) * 1.33
                },
                fi: function (a) {
                    if (a == -1) return 255;
                    return 210 + Math.atan(a / 1.33) * 45 / Math.PI * 2
                },
                g: q,
                orderRGB: function (a, c, e) {
                    return new v(e, c, a)
                }
            },
            BBR: {
                a: E.B,
                b: E.BR,
                f: function (a) {
                    if (a == 255) return -1;
                    return Math.tan((315 - a) / 60 * Math.PI / 2) * 1.33
                },
                fi: function (a) {
                    if (a == -1) return 255;
                    return 315 - Math.atan(a / 1.33) * 60 / Math.PI * 2
                },
                g: m,
                orderRGB: function (a, c, e) {
                    return new v(c, e, a)
                }
            },
            BRR: {
                a: E.BR,
                b: E.R,
                f: function (a) {
                    if (a == 0) return -1;
                    return Math.tan((a - 315) / 45 * Math.PI / 2) * 1.33
                },
                fi: function (a) {
                    if (a == -1) return 0;
                    return 315 + Math.atan(a / 1.33) * 45 / Math.PI * 2
                },
                g: q,
                orderRGB: function (a, c, e) {
                    return new v(a, e, c)
                }
            },
            getBaseColorByHue: function (a) {
                var c, e, h, k;
                a %= 360;
                k = this.getArc(a);
                h = k.f(a);
                e = k.g(k.a.HSV.V, k.b.HSV.V, h);
                c = k.g(k.a.HSV.S, k.b.HSV.S, h);
                return {
                    HSV: new s(a, c, e),
                    RGB: this._getRGB(a, c, e, k, h)
                }
            },
            getRGB: function (a, c, e) {
                var h, k;
                h = this.getArc(a);
                k = h.f(a);
                return this._getRGB(a, c, e, h, k)
            },
            _getRGB: function (a, c, e, h, k) {
                a = h.a.RGB;
                a = Math.max(a.R, Math.max(a.G, a.B));
                a *= e;
                c = a * (1 - c);
                return h.orderRGB(a, k == -1 ? c : (a + c * k) / (1 + k), c)
            },
            getColorByRGB: function (a) {
                var c, e, h;
                if (a.R == a.B && a.R == a.G) {
                    e = c = 0;
                    h = (a.R * 0.299 + a.G * 0.587 + a.B * 0.114) / 255
                } else {
                    h = Math.max(a.R, Math.max(a.G, a.B));
                    e = Math.min(a.R, Math.min(a.G, a.B));
                    if (h == a.R) if (e == a.B) {
                        a = a.G;
                        c = this.RRG
                    } else {
                        a = a.B;
                        c = this.BRR
                    } else if (h == a.G) if (e == a.R) {
                        a = a.B;
                        c = this.GGB
                    } else {
                        a = a.R;
                        c = this.RGG
                    } else if (e == a.R) {
                        a = a.G;
                        c = this.GBB
                    } else {
                        a = a.R;
                        c = this.BBR
                    }
                    a = a == e ? -1 : (h - a) / (a - e);
                    c = c.fi(a);
                    e = (h - e) / h;
                    h = h / 255
                }
                return new s(c, e, h)
            }
        };
        O = {
            m1: {
                getH: function () {
                    return {}
                },
                minD: 5,
                maxD: 90,
                getD: function () {
                    return 0
                }
            },
            m2: {
                getH: function (a) {
                    return {
                        C: (a + 180) % 360
                    }
                },
                minD: 5,
                maxD: 90,
                getD: function () {
                    return 0
                }
            },
            m3: {
                getH: function (a, c) {
                    return {
                        S1: (a + c + 180) % 360,
                        S2: (a - c + 540) % 360
                    }
                },
                minD: 5,
                maxD: 90,
                getD: function (a, c) {
                    var e = Math.abs(i(a + 180, c));
                    if (e < this.minD) e = this.minD;
                    if (e > this.maxD) e = this.maxD;
                    return e
                }
            },
            m4: {
                getH: function (a, c) {
                    return {
                        C: (a + 180) % 360,
                        S1: (a + c + 360) % 360,
                        S2: (a + c + 540) % 360
                    }
                },
                minD: 5,
                maxD: 90,
                getD: function (a, c) {
                    var e, h, k;
                    e = i(a, c);
                    k = Math.abs(e);
                    h = i(a + 180, c);
                    if (Math.abs(h) < k) e = h;
                    if (k < this.minD) e = e >= 0 ? this.minD : -this.minD;
                    if (k > this.maxD) e = e >= 0 ? this.maxD : -this.maxD;
                    return e
                }
            },
            m5: {
                getH: function (a, c) {
                    return {
                        S1: (a + c) % 360,
                        S2: (a - c + 360) % 360
                    }
                },
                minD: 5,
                maxD: 90,
                getD: function (a, c) {
                    var e = Math.abs(i(a, c));
                    if (e < this.minD) e = this.minD;
                    if (e > this.maxD) e = this.maxD;
                    return e
                }
            },
            m6: {
                getH: function (a, c) {
                    return {
                        C: (a + 180) % 360,
                        S1: (a + c) % 360,
                        S2: (a - c + 360) % 360
                    }
                },
                minD: 5,
                maxD: 90,
                getD: function (a, c) {
                    var e = Math.abs(i(a, c));
                    if (e < this.minD) e = this.minD;
                    if (e > this.maxD) e = this.maxD;
                    return e
                }
            }
        };
        Q = {
            shadow: [{
                dS: -0.5,
                dV: -0.5
            }, {
                dS: 1,
                dV: -0.7
            }],
            light: [{
                dS: -0.5,
                dV: 1
            }, {
                dS: -0.9,
                dV: 1
            }],
            get: function (a, c) {
                var e = [];
                e.push({
                    dS: this.shadow[0].dS * a,
                    dV: this.shadow[0].dV * a
                });
                e.push({
                    dS: this.shadow[1].dS * a,
                    dV: this.shadow[1].dV * a
                });
                e.push({
                    dS: this.light[0].dS * c,
                    dV: this.light[0].dV * c
                });
                e.push({
                    dS: this.light[1].dS * c,
                    dV: this.light[1].dV * c
                });
                return e
            }
        };
        this.Scheme = "m1";
        this.SchemeModel = O.m1;
        this.H = 0;
        this.Dist = 30;
        this.dV = this.dS = 0;
        this.cL = this.cS = 0.5;
        this.ContrastModel = Q.get(0.5, 0.5);
        this.UseVarsOverlay = false;
        this.VarsOverlay = [
            [],
            [],
            [],
            []
        ];
        this.Conversion = 0;
        this.Presets = {
            "default": {
                name: "Схема по умолчанию",
                dS: 0,
                dV: 0,
                cS: 0.5,
                cL: 0.5
            },
            hcontrast1: {
                name: "Больше контраста",
                dS: -0.1,
                dV: -0.1,
                cS: 0.66,
                cL: 0.66
            },
            hcontrast2: {
                name: "Высокий контраст",
                dS: -0.1,
                dV: -0.1,
                cS: 0.75,
                cL: 0.75
            },
            hcontrast3: {
                name: "Максимум контраста",
                dS: 1,
                dV: 1,
                cS: 1,
                cL: 1
            },
            lcontrast1: {
                name: "Меньше контраста",
                dS: 0,
                dV: 0,
                cS: 0.33,
                cL: 0.33
            },
            lcontrast2: {
                name: "Низкий контраст",
                dS: 0,
                dV: 0,
                cS: 0.2,
                cL: 0.2
            },
            lcontrast3: {
                name: "Минимум контраста",
                dS: 0,
                dV: 0,
                cS: 0.1,
                cL: 0.1
            },
            msatur: {
                name: "Средне-тёмный (насыщенный)",
                dS: 0.5,
                dV: -0.44,
                cS: 0.4,
                cL: 0.4
            },
            dsatur: {
                name: "Темный (насыщенный)",
                dS: 1,
                dV: -0.7,
                cS: 0.25,
                cL: 0.25
            },
            vdsatur: {
                name: "Очень темный (насыщенный)",
                dS: 1,
                dV: -0.8,
                cS: 0.1,
                cL: 0.1
            },
            pastel: {
                name: "Пастель",
                dS: -0.44,
                dV: -0.125,
                cS: 0.25,
                cL: 0.25
            },
            mpastel: {
                name: "Средне-тёмный пастель",
                dS: -0.44,
                dV: -0.44,
                cS: 0.25,
                cL: 0.25
            },
            dpastel: {
                name: "Темный пастель",
                dS: -0.44,
                dV: -0.7,
                cS: 0.25,
                cL: 0.25
            },
            vdpastel: {
                name: "Очень темный пастель",
                dS: -0.44,
                dV: -0.8,
                cS: 0.1,
                cL: 0.1
            },
            palepastel: {
                name: "Мягкий бледный пастель",
                dS: -0.75,
                dV: -0.1,
                cS: 0.1,
                cL: 0.1
            },
            mpalepastel: {
                name: "Средний бледный Pastel",
                dS: -0.75,
                dV: -0.44,
                cS: 0.1,
                cL: 0.1
            },
            dpalepastel: {
                name: "Темный бледный Pastel",
                dS: -0.75,
                dV: -0.7,
                cS: 0.1,
                cL: 0.1
            },
            vdpalepastel: {
                name: "Очень темный бледный Pastel",
                dS: -0.8,
                dV: -0.8,
                cS: 0.05,
                cL: 0.05
            },
            lgray: {
                name: "Полутон (лёгкий)",
                dS: -0.95,
                dV: -0.1,
                cS: 0.1,
                cL: 0.1
            },
            lagray: {
                name: "Серый полутон с цветовым акцентом (лёгкий)",
                dS: -0.95,
                dV: -0.1,
                cS: 0.5,
                cL: 0.5
            },
            mgray: {
                name: "Серый полутон (средний)",
                dS: -0.95,
                dV: -0.44,
                cS: 0.1,
                cL: 0.1
            },
            magray: {
                name: "Серый полутон с цветовым акцентом (средний)",
                dS: -0.95,
                dV: -0.44,
                cS: 0.5,
                cL: 0.5
            },
            dgray: {
                name: "Серый полутон (тёмный)",
                dS: -0.95,
                dV: -0.8,
                cS: 0.1,
                cL: 0.1
            },
            dagray: {
                name: "Серый полутон с цветовым акцентом (тёмный)",
                dS: -0.95,
                dV: -0.8,
                cS: 0.5,
                cL: 0.5
            }
        };
        this.ColorHash = {
            pri: 0,
            sec1: 1,
            sec2: 2,
            compl: 3
        };
        this.setScheme = function (a) {
            this.Scheme = a;
            this.SchemeModel = O[this.Scheme];
            this.resetVarsOverlay(false);
            this.Sec1 && this.setDist(this.Sec1.H)
        };
        this.setHue = function (a) {
            if (this.H === a) return false;
            this.H = Math.round(a) % 360;
            this.resetVarsOverlay(false);
            return true
        };
        this.setHSV = function (a) {
            this.setHue(a.H);
            var c = this.Primary.Base.HSV;
            this.dS = c.S == 0 ? 0 : a.S > c.S ? (a.S - c.S) / (1 - c.S) : a.S / c.S - 1;
            this.dV = c.V == 0 ? 0 : a.V > c.V ? (a.V - c.V) / (1 - c.V) : a.V / c.V - 1;
            this.resetVarsOverlay(false)
        };
        this.setHex = function (a) {
            if (a = f(a)) {
                hsv = I.getColorByRGB(a);
                this.setHSV(hsv)
            }
        };
        this.setDist = function (a) {
            this.Dist = this.SchemeModel.getD(this.H, a);
            this.resetVarsOverlay(false);
            return true
        };
        this.setDistNum = function (a) {
            this.Dist = a;
            this.resetVarsOverlay(false);
            return true
        };
        this.setSV = function (a, c) {
            this.dS = a;
            this.dV = c;
            this.resetVarsOverlay(false)
        };
        this.setContrast = function (a, c) {
            this.UseVarsOverlay = false;
            this.cS = a;
            this.cL = c;
            this.ContrastModel = Q.get(a, c);
            this.resetVarsOverlay(false)
        };
        this.resetVarsOverlay = function (a) {
            this.UseVarsOverlay = false;
            this.VarsOverlay = [
                [],
                [],
                [],
                []
            ];
            a || this.update()
        };
        this.setConversion = function (a) {
            this.Conversion = a;
            this.update()
        };
        this.setVarOverlay = function (a, c, e, h, k) {
            this.UseVarsOverlay = true;
            this.VarsOverlay[a][c] = [e, h];
            k || this.update()
        };
        this.getVarOverlay = function (a, c) {
            var e;
            if (e = this.VarsOverlay[a][c]) return e;
            e = this.getColorByIdx(a).Col[c].HSV;
            return [e.S, e.V]
        };
        this.update = function (a) {
            var c = this.SchemeModel.getH(this.H, this.Dist);
            if (!a) {
                this.Primary = new t(this.H, this.dS, this.dV, this.ContrastModel, this.VarsOverlay[0], this.Conversion);
                this.Compl = c.C == undefined ? null : new t(c.C, this.dS, this.dV, this.ContrastModel, this.VarsOverlay[3], this.Conversion)
            }
            this.Sec1 = c.S1 == undefined ? null : new t(c.S1, this.dS, this.dV, this.ContrastModel, this.VarsOverlay[1], this.Conversion);
            this.Sec2 = c.S2 == undefined ? null : new t(c.S2, this.dS, this.dV, this.ContrastModel, this.VarsOverlay[2], this.Conversion)
        };
        this.serialize = function () {
            var a, c, e = "";
            e += w.encodeInt(this.H, 2);
            a = parseInt(this.Scheme.substring(1), 10);
            c = 8 * this.Conversion;
            e += w.encodeInt(a + c, 1);
            e += w.encodeInt(this.Dist + 90, 2);
            e += w.encodeFloat((this.dS + 1) / 2, 2);
            e += w.encodeFloat((this.dV + 1) / 2, 2);
            e += w.encodeFloat(this.cS, 2);
            e += w.encodeFloat(this.cL, 2);
            if (this.UseVarsOverlay) for (a = 0; a < 4; a++) for (c = 0; c < 5; c++) if (this.VarsOverlay[a][c]) {
                e += w.encodeInt(8 * a + c, 1);
                e += w.encodeFloat((this.VarsOverlay[a][c][0] + 1) / 2, 2);
                e += w.encodeFloat((this.VarsOverlay[a][c][1] + 1) / 2, 2)
            }
            return e
        };
        this.unserialize = function (a) {
            var c, e, h = {},
                k = 0,
                o;
            c = a.substring(k, k + 2);
            c = w.decodeInt(c);
            if (c >= 0 && c < 360) h.H = c;
            else
            return false;
            k += 2;
            c = a.substring(k, k + 1);
            c = w.decodeInt(c);
            e = "m" + c % 8;
            if (O[e]) h.Scheme = e;
            else
            return false;
            h.Conversion = Math.floor(c / 8);
            k += 1;
            c = a.substring(k, k + 2);
            c = w.decodeInt(c) - 90;
            if (c >= -90 && c <= 90) h.Dist = c;
            else
            return false;
            k += 2;
            c = a.substring(k, k + 2);
            c = w.decodeFloat(c, 2, 5) * 2 - 1;
            if (c >= -1 && c <= 1) h.dS = c;
            else
            return false;
            k += 2;
            c = a.substring(k, k + 2);
            c = w.decodeFloat(c, 2, 5) * 2 - 1;
            if (c >= -1 && c <= 1) h.dV = c;
            else
            return false;
            k += 2;
            c = a.substring(k, k + 2);
            c = w.decodeFloat(c, 2, 5);
            if (c >= 0 && c <= 1) h.cS = c;
            else
            return false;
            k += 2;
            c = a.substring(k, k + 2);
            c = w.decodeFloat(c, 2, 5);
            if (c >= 0 && c <= 1) h.cL = c;
            else
            return false;
            k += 2;
            this.setAll(h);
            if (a.length > k) {
                for (; a.length > k;) {
                    c = a.substring(k, k + 1);
                    c = w.decodeInt(c);
                    e = Math.floor(c / 8);
                    h = c - e * 8;
                    if (e < 0 || e > 3 || h < 0 || h > 4) return false;
                    k += 1;
                    c = a.substring(k, k + 2);
                    o = w.decodeFloat(c, 2, 5) * 2 - 1;
                    if (o < -1 || o > 1) return false;
                    k += 2;
                    c = a.substring(k, k + 2);
                    c = w.decodeFloat(c, 2, 5) * 2 - 1;
                    if (c < -1 || c > 1) return false;
                    k += 2;
                    this.setVarOverlay(e, h, o, c, true)
                }
                this.update()
            }
        };
        this.setAll = function (a) {
            this.Scheme = a.Scheme;
            this.SchemeModel = O[this.Scheme];
            ColorSchemeDesigner.broadcast("setConversion", a.Conversion);
            this.H = a.H;
            this.Dist = a.Dist;
            this.dS = a.dS;
            this.dV = a.dV;
            this.cS = a.cS;
            this.cL = a.cL;
            this.ContrastModel = Q.get(this.cS, this.cL);
            this.resetVarsOverlay()
        };
        this.getPreset = function (a) {
            if (this.Presets[a]) return this.Presets[a];
            return this.Presets["default"]
        };
        this.usePreset = function (a) {
            this.resetVarsOverlay();
            a = this.getPreset(a);
            this.setSV(a.dS, a.dV);
            this.setContrast(a.cS, a.cL)
        };
        this.getColorByIdx = function (a) {
            var c = ["Primary", "Sec1", "Sec2", "Compl"];
            c[a] || (a = 0);
            return this[c[a]]
        };
        this.ColorBlind = {
            getHex: function (a, c, e, h) {
                function k(W, Y, Z, aa) {
                    return Math.round(W - Math.abs((Z - aa) / 51) * (W - Y))
                }
                var o, n, u, F, K, L, R;
                o = Math.round(a / 51) * 51;
                n = Math.round(c / 51) * 51;
                u = Math.round(e / 51) * 51;
                F = o < a ? o + 51 : o > a ? o - 51 : o;
                K = n < c ? n + 51 : n > c ? n - 51 : n;
                L = u < e ? u + 51 : u > e ? u - 51 : u;
                R = this.colTbl[b(o) + b(n) + b(u)][h];
                h = this.colTbl[b(F) + b(K) + b(L)][h];
                a = k(d(R.substring(0, 2)), d(h.substring(0, 2)), o, a);
                c = k(d(R.substring(2, 4)), d(h.substring(2, 4)), n, c);
                e = k(d(R.substring(4, 6)), d(h.substring(4, 6)), u, e);
                return b(a) + b(c) + b(e)
            },
            typeDesc: ["Нормальное зрение (~85.5% населения)", "Протанопия (1% мужчин)", "Дейтеранопия (1% мужчин)", "Тританопия (~0,003% населения)", "Протаномалия (1% мужчин)", "Дейтераномалия (5% мужчин, 0.4% женщин)", "Тританомалия (близко к 0%)", "Полный дальтонизм (0,005% населения)", "Нетипичный монохроматизм"],
            colTbl: {
                FFFFFF: ["FFFFFF", "FFFAFA", "FFE8EF", "F4F0FF", "FFFCFC", "FFF3F7", "F9F7FF", "FFFFFF", "FFFFFF"],
                FFFFCC: ["FFFFCC", "FFF2C8", "FFDFC8", "FDEFFF", "FFF8CA", "FFEFCA", "FEF7E5", "EEEEEE", "F1F1E7"],
                FFFF99: ["FFFF99", "FFEDA2", "FFDAAD", "FFEAF9", "FFF69D", "FFECA3", "FFF4C9", "DDDDDD", "E3E3CF"],
                FFFF66: ["FFFF66", "FFEA86", "FFD79D", "FFE6F5", "FFF476", "FFEB81", "FFF2AD", "CCCCCC", "D6D6B7"],
                FFFF33: ["FFFF33", "FFE975", "FFD594", "FFE5F3", "FFF454", "FFEA63", "FFF293", "BBBBBB", "C8C89F"],
                FFFF00: ["FFFF00", "FFE871", "FFD592", "FFE4F2", "FFF338", "FFEA49", "FFF179", "AAAAAA", "BBBB88"],
                FFCCFF: ["FFCCFF", "CFD7FF", "E1D8FD", "FBD1E1", "E7D1FF", "F0D2FE", "FDCEF0", "EEEEEE", "F1E7F1"],
                FFCCCC: ["FFCCCC", "DED8D2", "F1D2CB", "FFCAD8", "EED2CF", "F8CFCB", "FFCBD2", "DDDDDD", "E3D9D9"],
                FFCC99: ["FFCC99", "E5D69D", "FCCD99", "FFC4D1", "F2D19B", "FDCC99", "FFC8B5", "CCCCCC", "D6CCC1"],
                FFCC66: ["FFCC66", "E9D469", "FFCA6F", "FFC0CD", "F4D067", "FFCB6A", "FFC699", "BBBBBB", "C8BEAA"],
                FFCC33: ["FFCC33", "ECD435", "FFC857", "FFBFCA", "F5D034", "FFCA45", "FFC57E", "AAAAAA", "BBB092"],
                FFCC00: ["FFCC00", "ECD30F", "FFC750", "FFBECA", "F5CF07", "FFC928", "FFC565", "999999", "ADA37A"],
                FF99FF: ["FF99FF", "AABDFF", "B0BCF9", "F6A9B5", "D4ABFF", "D7AAFC", "FAA1DA", "DDDDDD", "E3CFE3"],
                FF99CC: ["FF99CC", "B1B8E0", "C5B5C7", "FC9FAA", "D8A8D6", "E2A7C9", "FD9CBB", "CCCCCC", "D6C1CC"],
                FF9999: ["FF9999", "BDB6A8", "D2B095", "FF99A2", "DEA7A0", "E8A497", "FF999D", "BBBBBB", "C8B4B4"],
                FF9966: ["FF9966", "C4B470", "DAAC62", "FF959E", "E1A66B", "ECA264", "FF9782", "AAAAAA", "BBA69C"],
                FF9933: ["FF9933", "C7B43A", "DEAB2A", "FF949D", "E3A636", "EEA22E", "FF9668", "999999", "AD9984"],
                FF9900: ["FF9900", "C8B317", "DFAA00", "FF949C", "E3A60B", "EFA100", "FF964E", "888888", "9F8B6C"],
                FF66FF: ["FF66FF", "98B2FF", "85A7F5", "F28791", "CB8CFF", "C286FA", "F876C8", "CCCCCC", "D6B7D6"],
                FF66CC: ["FF66CC", "82A0F6", "A09FC3", "F87981", "C083E1", "CF82C7", "FB6FA6", "BBBBBB", "C8AABE"],
                FF6699: ["FF6699", "999DB9", "B19992", "FD6E74", "CC81A9", "D87F95", "FE6A86", "AAAAAA", "BB9CA6"],
                FF6666: ["FF6666", "A59B7C", "BB955E", "FF666C", "D28071", "DD7D62", "FF6669", "999999", "AD8E8E"],
                FF6633: ["FF6633", "AA9A42", "BF9322", "FF656A", "D4803A", "DF7C2A", "FF654E", "888888", "9F8177"],
                FF6600: ["FF6600", "AC9A1E", "C09300", "FF6569", "D5800F", "DF7C00", "FF6534", "777777", "92735F"],
                FF33FF: ["FF33FF", "96B1FF", "679BF2", "F07178", "CA72FF", "B367F8", "F752BB", "BBBBBB", "C89FC8"],
                FF33CC: ["FF33CC", "779DFF", "8A92C1", "F75E63", "BB68E5", "C462C6", "FB4897", "AAAAAA", "BB92B0"],
                FF3399: ["FF3399", "7A8ECE", "9D8B8F", "FB4C4F", "BC60B3", "CE5F94", "FD3F74", "999999", "AD8499"],
                FF3366: ["FF3366", "8F8C8B", "A7875C", "FE3D3E", "C75F78", "D35D61", "FE3852", "888888", "9F7781"],
                FF3333: ["FF3333", "988B4A", "AD841C", "FF3332", "CB5F3E", "D65B27", "FF3332", "777777", "926969"],
                FF3300: ["FF3300", "9A8B23", "AE8600", "FF3331", "CC5F11", "D65C00", "FF3318", "666666", "845B51"],
                FF00FF: ["FF00FF", "96B1FF", "5E98F1", "F06A71", "CA58FF", "AE4CF8", "F735B8", "AAAAAA", "BB88BB"],
                FF00CC: ["FF00CC", "7BA0FF", "838FC0", "F6555A", "BD50E5", "C147C6", "FA2A93", "999999", "AD7AA3"],
                FF0099: ["FF0099", "6E89D7", "97888E", "FA4042", "B644B8", "CB4493", "FC206D", "888888", "9F6C8B"],
                FF0066: ["FF0066", "888892", "A2835B", "FD2B28", "C3447C", "D04160", "FE1547", "777777", "925F73"],
                FF0033: ["FF0033", "93874E", "A8801A", "FE1A00", "C94340", "D34026", "FE0D19", "666666", "84515B"],
                FF0000: ["FF0000", "968726", "A98200", "FE1C00", "CA4313", "D44100", "FE0E00", "555555", "774444"],
                CCFFFF: ["CCFFFF", "F8F4F8", "FFEAFD", "CBEFFF", "E2F9FB", "E5F4FE", "CBF7FF", "EEEEEE", "E7F1F1"],
                CCFFCC: ["CCFFCC", "FFF1C5", "FFDECC", "D3EFFF", "E5F8C8", "E5EECC", "CFF7E5", "DDDDDD", "D9E3D9"],
                CCFF99: ["CCFF99", "FFEB97", "FFD8AB", "D9EEFF", "E5F598", "E5EBA2", "D2F6CC", "CCCCCC", "CCD6C1"],
                CCFF66: ["CCFF66", "FFE873", "FFD497", "DDEEFF", "E5F36C", "E5E97E", "D4F6B2", "BBBBBB", "BEC8AA"],
                CCFF33: ["CCFF33", "FFE75C", "FFD38C", "E0EEFF", "E5F347", "E5E95F", "D6F699", "AAAAAA", "B0BB92"],
                CCFF00: ["CCFF00", "FFE655", "FFD389", "E0EEFF", "E5F22A", "E5E944", "D6F67F", "999999", "A3AD7A"],
                CCCCFF: ["CCCCFF", "C4CEFF", "CBCCFF", "C6D1E1", "C8CDFF", "CBCCFF", "C9CEF0", "DDDDDD", "D9D9E3"],
                CCCCCC: ["CCCCCC", "CFCBCB", "DEC6CD", "CECAD9", "CDCBCB", "D5C9CC", "CDCBD2", "CCCCCC", "CCCCCC"],
                CCCC99: ["CCCC99", "D7C997", "EAC19B", "D3C4D3", "D1CA98", "DBC69A", "CFC8B6", "BBBBBB", "BEBEB4"],
                CCCC66: ["CCCC66", "DBC764", "F1BE6A", "D7C1CF", "D3C965", "DEC568", "D1C69A", "AAAAAA", "B0B09C"],
                CCCC33: ["CCCC33", "DDC631", "F5BC3B", "D8BFCD", "D4C932", "E0C437", "D2C580", "999999", "A3A384"],
                CCCC00: ["CCCC00", "DDC600", "F6C600", "D9BECC", "D4C900", "E1C900", "D2C566", "888888", "95956C"],
                CC99FF: ["CC99FF", "98B1FF", "8FAEFB", "BFA9B6", "B2A5FF", "ADA3FD", "C5A1DA", "CCCCCC", "CCC1D6"],
                CC99CC: ["CC99CC", "9EA8D7", "AAA7C9", "C79FAB", "B5A0D1", "BBA0CA", "C99CBB", "BBBBBB", "BEB4BE"],
                CC9999: ["CC9999", "AAA5A0", "BAA198", "CD98A2", "BB9F9C", "C39D98", "CC989D", "AAAAAA", "B0A6A6"],
                CC9966: ["CC9966", "B1A46A", "C49D65", "D0929D", "BE9E68", "C89B65", "CE9581", "999999", "A3998E"],
                CC9933: ["CC9933", "B5A336", "C99B32", "D2909A", "C09E34", "CA9A32", "CF9466", "888888", "958B77"],
                CC9900: ["CC9900", "B5A20E", "CA9A00", "D38F99", "C09D07", "CB9900", "CF944C", "777777", "887D5F"],
                CC66FF: ["CC66FF", "87A7FF", "4C97F6", "BB8791", "A986FF", "8C7EFA", "C376C8", "BBBBBB", "BEAAC8"],
                CC66CC: ["CC66CC", "648CEB", "7B8DC5", "C37982", "9879DB", "A379C8", "C76FA7", "AAAAAA", "B09CB0"],
                CC6699: ["CC6699", "7F88AF", "918694", "C96E75", "A577A4", "AE7696", "CA6A87", "999999", "A38E99"],
                CC6666: ["CC6666", "8C8675", "9E8161", "CC656C", "AC766D", "B57363", "CC6569", "888888", "958181"],
                CC6633: ["CC6633", "92853C", "A47E2B", "CE6067", "AF7537", "B8722F", "CD634D", "777777", "887369"],
                CC6600: ["CC6600", "948415", "A67F00", "CF5F65", "B0750A", "B97200", "CD6232", "666666", "7A6651"],
                CC33FF: ["CC33FF", "8AAAFF", "008DEF", "B87178", "AB6EFF", "6660F7", "C252BB", "AAAAAA", "B092BB"],
                CC33CC: ["CC33CC", "4387FF", "577EC2", "C15E64", "875DE5", "9158C7", "C64898", "999999", "A384A3"],
                CC3399: ["CC3399", "5275C8", "767591", "C64C50", "8F54B0", "A15495", "C93F74", "888888", "95778B"],
                CC3366: ["CC3366", "707387", "856F5F", "CA3D3F", "9E5376", "A85162", "CB3852", "777777", "886973"],
                CC3333: ["CC3333", "7B7146", "8C6C27", "CC3334", "A3523C", "AC4F2D", "CC3333", "666666", "7A5B5B"],
                CC3300: ["CC3300", "7E711B", "8F6D00", "CC3030", "A5520D", "AD5000", "CC3118", "555555", "6C4E44"],
                CC00FF: ["CC00FF", "8CABFF", "008CEC", "B76A71", "AC55FF", "6646F5", "C135B8", "999999", "A37AAD"],
                CC00CC: ["CC00CC", "5D91FF", "4B7AC0", "C0555A", "9448E5", "8B3DC6", "C62A93", "888888", "956C95"],
                CC0099: ["CC0099", "356FD5", "6E7190", "C64043", "8037B7", "9D3894", "C9206E", "777777", "885F7D"],
                CC0066: ["CC0066", "646D90", "7E6A5E", "CA2B2B", "98367B", "A53562", "CB1548", "666666", "7A5166"],
                CC0033: ["CC0033", "746C4C", "856726", "CB170B", "A0363F", "A8332C", "CB0B1F", "555555", "6C444E"],
                CC0000: ["CC0000", "786C1E", "886900", "CC1600", "A2360F", "AA3400", "CC0B00", "444444", "5F3636"],
                "99FFFF": ["99FFFF", "EFECF4", "F4E4FF", "A6EFFF", "C4F5F9", "C6F1FF", "9FF7FF", "DDDDDD", "CFE3E3"],
                "99FFCC": ["99FFCC", "F7E9C1", "FFDDD0", "ACEFFF", "C8F4C6", "CCEECE", "A2F7E5", "CCCCCC", "C1D6CC"],
                "99FF99": ["99FF99", "FBE790", "FFD6A9", "B0EEFF", "CAF394", "CCEAA1", "A4F6CC", "BBBBBB", "B4C8B4"],
                "99FF66": ["99FF66", "FEE65E", "FFD291", "B4EEFF", "CBF262", "CCE87B", "A6F6B2", "AAAAAA", "A6BB9C"],
                "99FF33": ["99FF33", "FFE532", "FFD184", "B5EDFF", "CCF232", "CCE85B", "A7F699", "999999", "99AD84"],
                "99FF00": ["99FF00", "FFE41C", "FFD080", "B6EDFF", "CCF10E", "CCE740", "A7F67F", "888888", "8B9F6C"],
                "99CCFF": ["99CCFF", "B9C5FA", "B9C4FF", "91D1E1", "A9C8FC", "A9C8FF", "95CEF0", "CCCCCC", "C1CCD6"],
                "99CCCC": ["99CCCC", "C4C1C6", "CEBDCF", "9CCAD9", "AEC6C9", "B3C4CD", "9ACBD2", "BBBBBB", "B4BEBE"],
                "99CC99": ["99CC99", "CBBF93", "DBB89D", "A3C4D3", "B2C596", "BAC29B", "9EC8B6", "AAAAAA", "A6B0A6"],
                "99CC66": ["99CC66", "CFBD61", "E4B56C", "A8C1CF", "B4C463", "BEC069", "A0C69A", "999999", "99A38E"],
                "99CC33": ["99CC33", "D1BC2F", "E8B33F", "AABFCD", "B5C431", "C0BF39", "A1C580", "888888", "8B9577"],
                "99CC00": ["99CC00", "D2BC00", "E9B22A", "ABBECD", "B5C400", "C1BF15", "A2C566", "777777", "7D885F"],
                "9999FF": ["9999FF", "83A4FF", "6FA4FD", "86A9B6", "8E9EFF", "849EFE", "8FA1DA", "BBBBBB", "B4B4C8"],
                "9999CC": ["9999CC", "8F9CCE", "929BCC", "929FAB", "949ACD", "959ACC", "959CBB", "AAAAAA", "A6A6B0"],
                "999999": ["999999", "9B9899", "A6949A", "9A97A3", "9A9899", "9F9699", "99989E", "999999", "999999"],
                "999966": ["999966", "A29665", "B29068", "9F929D", "9D9765", "A59467", "9C9581", "888888", "8B8B81"],
                "999933": ["999933", "A59532", "B78E37", "A2909A", "9F9732", "A89335", "9D9466", "777777", "7D7D69"],
                "999900": ["999900", "A69500", "A69500", "A28F99", "9F9700", "9F9700", "9D944C", "666666", "707051"],
                "9966FF": ["9966FF", "709BFF", "0090F3", "7E8791", "8480FF", "4C7BF9", "8B76C8", "AAAAAA", "A69CBB"],
                "9966CC": ["9966CC", "497BDF", "507FC7", "8C7982", "7170D5", "7472C9", "926FA7", "999999", "998EA3"],
                "996699": ["996699", "6A77A5", "737696", "946D75", "816E9F", "866E97", "966987", "888888", "8B818B"],
                "996666": ["996666", "78746D", "847064", "9A656C", "886D69", "8E6B65", "996569", "777777", "7D7373"],
                "996633": ["996633", "7E7237", "8C6D31", "9C6067", "8B6C35", "926932", "9A634D", "666666", "70665B"],
                "996600": ["996600", "7F720D", "8E6C00", "9D5F66", "8C6C06", "936900", "9B6233", "555555", "625844"],
                "9933FF": ["9933FF", "7DA2FF", "008DE8", "7A7078", "8B6AFF", "4C60F3", "8951BB", "999999", "9984AD"],
                "9933CC": ["9933CC", "007AF6", "0073C2", "885D64", "4C56E1", "4C53C7", "904898", "888888", "8B7795"],
                "993399": ["993399", "005EBF", "496192", "914C51", "4C48AC", "714A95", "953F75", "777777", "7D697D"],
                "993366": ["993366", "505B80", "625961", "963D40", "744773", "7D4663", "973853", "666666", "705B66"],
                "993333": ["993333", "5F5941", "6C552D", "993335", "7C463A", "824430", "993334", "555555", "624E4E"],
                "993300": ["993300", "635913", "705600", "9A3032", "7E4609", "844400", "993119", "444444", "554036"],
                "9900FF": ["9900FF", "83A6FF", "008CE5", "796A71", "8E53FF", "4C46F2", "8935B8", "888888", "8B6C9F"],
                "9900CC": ["9900CC", "2782FF", "0073C0", "87555B", "6041E5", "4C39C6", "902A93", "777777", "7D5F88"],
                "990099": ["990099", "0067D0", "385B90", "904044", "4C33B4", "682D94", "94206E", "666666", "705170"],
                "990066": ["990066", "39538F", "57535F", "962B2C", "69297A", "782962", "971549", "555555", "624458"],
                "990033": ["990033", "55514A", "634E2C", "981612", "77283E", "7E272F", "980B22", "444444", "553640"],
                "990000": ["990000", "5A5117", "674F00", "991100", "79280B", "802700", "990800", "333333", "472828"],
                "66FFFF": ["66FFFF", "EAE7F0", "EBDFFF", "88EFFF", "A8F3F7", "A8EFFF", "77F7FF", "CCCCCC", "B7D6D6"],
                "66FFCC": ["66FFCC", "F1E4BF", "FFDDD3", "8BEFFF", "ABF1C5", "B2EECF", "78F7E5", "BBBBBB", "AAC8BE"],
                "66FF99": ["66FF99", "F6E28D", "FFD5A7", "8EEEFF", "AEF093", "B2EAA0", "7AF6CC", "AAAAAA", "9CBBA6"],
                "66FF66": ["66FF66", "F8E15D", "FFD08B", "90EEFF", "AFF061", "B2E778", "7BF6B2", "999999", "8EAD8E"],
                "66FF33": ["66FF33", "FAE02A", "FFCF7C", "92EDFF", "B0EF2E", "B2E757", "7CF699", "888888", "819F77"],
                "66FF00": ["66FF00", "FAE000", "FFCE79", "92EDFF", "B0EF00", "B2E63C", "7CF67F", "777777", "73925F"],
                "66CCFF": ["66CCFF", "B2BEF5", "ADBEFF", "57D1E1", "8CC5FA", "89C5FF", "5ECEF0", "BBBBBB", "AABEC8"],
                "66CCCC": ["66CCCC", "BDBBC1", "C3B7D1", "6BCAD9", "91C3C6", "94C1CE", "68CBD2", "AAAAAA", "9CB0B0"],
                "66CC99": ["66CC99", "C4B88F", "D2B29F", "77C4D3", "95C294", "9CBF9C", "6EC8B6", "999999", "8EA399"],
                "66CC66": ["66CC66", "C8B65E", "DAAE6E", "7EC1CF", "97C162", "A0BD6A", "72C69A", "888888", "819581"],
                "66CC33": ["66CC33", "CAB52D", "DFAC42", "81BFCD", "98C030", "A2BC3A", "73C580", "777777", "738869"],
                "66CC00": ["66CC00", "CAB500", "E0AC2E", "82BECD", "98C000", "A3BC17", "74C566", "666666", "667A51"],
                "6699FF": ["6699FF", "6E98FE", "519CFE", "3EA9B6", "6A98FE", "5B9AFE", "52A1DA", "AAAAAA", "9CA6BB"],
                "6699CC": ["6699CC", "8593C7", "8093CD", "5A9FAB", "7596C9", "7396CC", "609CBB", "999999", "8E99A3"],
                "669999": ["669999", "918F93", "978C9C", "6997A3", "7B9496", "7E929A", "67989E", "888888", "818B8B"],
                "669966": ["669966", "988C61", "A4876A", "71929D", "7F9263", "859068", "6B9581", "777777", "737D73"],
                "669933": ["669933", "9B8B2F", "AA853B", "74909A", "809231", "888F37", "6D9466", "666666", "66705B"],
                "669900": ["669900", "9B8B00", "AC8421", "758F9A", "809200", "898E10", "6D944D", "555555", "586244"],
                "6666FF": ["6666FF", "518DFF", "0090EE", "228791", "5B79FF", "337BF6", "4476C8", "999999", "8E8EAD"],
                "6666CC": ["6666CC", "326ED5", "0076C9", "4D7982", "4C6AD0", "336ECA", "596FA7", "888888", "818195"],
                "666699": ["666699", "59699C", "586A98", "5E6D75", "5F679A", "5F6898", "626987", "777777", "73737D"],
                "666666": ["666666", "686666", "6F6367", "67656C", "676666", "6A6466", "666569", "666666", "666666"],
                "666633": ["666633", "6D6432", "795F35", "6B6067", "696532", "6F6234", "68634D", "555555", "58584E"],
                "666600": ["666600", "6F6300", "7B5E11", "6C5F66", "6A6400", "706208", "696233", "444444", "4A4A36"],
                "6633FF": ["6633FF", "6E9AFF", "008CE4", "007179", "6A66FF", "335FF1", "3352BC", "888888", "81779F"],
                "6633CC": ["6633CC", "0074EA", "0076C2", "445D64", "3353DB", "3354C7", "554898", "777777", "736988"],
                "663399": ["663399", "0059B4", "005995", "584C51", "3346A6", "334697", "5F3F75", "666666", "665B70"],
                "663366": ["663366", "324676", "3D4763", "623D41", "4C3C6E", "513D64", "643853", "555555", "584E58"],
                "663333": ["663333", "46433A", "4F4031", "663336", "563B36", "5A3932", "663334", "444444", "4A4040"],
                "663300": ["663300", "4A420B", "534000", "673033", "583A05", "5C3900", "663119", "333333", "3D3328"],
                "6600FF": ["6600FF", "7AA1FF", "008BE1", "006B73", "7050FF", "3345F0", "3335B9", "777777", "735F92"],
                "6600CC": ["6600CC", "007CF8", "0076BF", "42545B", "333EE2", "333BC5", "542A93", "666666", "66517A"],
                "660099": ["660099", "0065CA", "005A94", "563F44", "3332B1", "332D96", "5E1F6E", "555555", "584462"],
                "660066": ["660066", "00478E", "253D60", "602B2D", "33237A", "451E63", "631549", "444444", "4A364A"],
                "660033": ["660033", "323748", "3F352F", "651615", "4C1B3D", "521A31", "650B24", "333333", "3D2833"],
                "660000": ["660000", "3C360F", "453500", "660B00", "511B07", "551A00", "660500", "222222", "2F1B1B"],
                "33FFFF": ["33FFFF", "E7E5EF", "E7DDFF", "74EFFF", "8DF2F7", "8DEEFF", "53F7FF", "BBBBBB", "9FC8C8"],
                "33FFCC": ["33FFCC", "EEE2BD", "FCDBD4", "76EFFF", "90F0C4", "97EDD0", "54F7E5", "AAAAAA", "92BBB0"],
                "33FF99": ["33FF99", "F3DF8C", "FFD4A6", "78EEFF", "93EF92", "99E99F", "55F6CC", "999999", "84AD99"],
                "33FF66": ["33FF66", "F5DE5C", "FFCF88", "79EEFF", "94EE61", "99E777", "56F6B2", "888888", "779F81"],
                "33FF33": ["33FF33", "F7DD29", "FFCD78", "7AEDFF", "95EE2E", "99E655", "56F699", "777777", "699269"],
                "33FF00": ["33FF00", "F7DD00", "FFCD74", "7AEDFF", "95EE00", "99E63A", "56F67F", "666666", "5B8451"],
                "33CCFF": ["33CCFF", "AEBBF2", "A7BBFF", "00D1E0", "70C3F8", "6DC3FF", "19CEEF", "AAAAAA", "92B0BB"],
                "33CCCC": ["33CCCC", "B9B7BF", "BDB4D1", "3ECAD9", "76C1C5", "78C0CE", "38CBD2", "999999", "84A3A3"],
                "33CC99": ["33CC99", "C0B48E", "CCAEA0", "54C4D3", "79C093", "7FBD9C", "43C8B6", "888888", "77958B"],
                "33CC66": ["33CC66", "C4B25D", "D6AB6F", "5EC1CF", "7BBF61", "84BB6A", "48C69A", "777777", "698873"],
                "33CC33": ["33CC33", "C6B22C", "DAA943", "63BFCD", "7CBF2F", "86BA3B", "4BC580", "666666", "5B7A5B"],
                "33CC00": ["33CC00", "C6B100", "DBA830", "64BFD7", "7CBE00", "87BA18", "4BC56B", "555555", "4E6C44"],
                "3399FF": ["3399FF", "6993FA", "3999FF", "00ABB7", "4E96FC", "3699FF", "19A2DB", "999999", "8499AD"],
                "3399CC": ["3399CC", "7F8EC3", "758FCE", "00A0AC", "5993C7", "5494CD", "199CBC", "888888", "778B95"],
                "339999": ["339999", "8C8A90", "8F879D", "3997A3", "5F9194", "61909B", "36989E", "777777", "697D7D"],
                "339966": ["339966", "92875E", "9D826B", "49929D", "629062", "688D68", "3E9581", "666666", "5B7066"],
                "339933": ["339933", "95862E", "A4803C", "4F909A", "648F30", "6B8C37", "419466", "555555", "4E624E"],
                "339900": ["339900", "958600", "A58600", "518F9A", "648F00", "6C8F00", "42944D", "444444", "405536"],
                "3366FF": ["3366FF", "2581FF", "0090EC", "009099", "2C73FF", "197BF5", "197BCC", "888888", "77819F"],
                "3366CC": ["3366CC", "2067CD", "0078C9", "007F87", "2966CC", "196FCA", "1972A9", "777777", "697388"],
                "336699": ["336699", "506195", "43639A", "146D76", "416397", "3B6499", "236987", "666666", "5B6670"],
                "336666": ["336666", "5E5D61", "615B68", "35656D", "486163", "4A6067", "346569", "555555", "4E5858"],
                "336633": ["336633", "645B2F", "6D5737", "3F6068", "4B6031", "505E35", "39634D", "444444", "404A40"],
                "336600": ["336600", "655B00", "705617", "415F66", "4C6000", "515E0B", "3A6233", "333333", "333D28"],
                "3333FF": ["3333FF", "6094FF", "008CE2", "008187", "4963FF", "195FF0", "195AC3", "777777", "696992"],
                "3333CC": ["3333CC", "0070E1", "0078C2", "006A70", "1951D6", "1955C7", "194E9E", "666666", "5B5B7A"],
                "333399": ["333399", "0054AA", "005D99", "005056", "1943A1", "194899", "194177", "555555", "4E4E62"],
                "333366": ["333366", "19376A", "003B65", "263C41", "263568", "193765", "2C3753", "444444", "40404A"],
                "333333": ["333333", "343333", "373133", "333236", "333333", "353233", "333234", "333333", "333333"],
                "333300": ["333300", "373200", "3D2F09", "363033", "353200", "383104", "343119", "222222", "25251B"],
                "3300FF": ["3300FF", "739DFF", "008BDF", "007C82", "534EFF", "1945EF", "193EC0", "666666", "5B5184"],
                "3300CC": ["3300CC", "0079F2", "0076BF", "006469", "193CDF", "193BC5", "19329A", "555555", "4E446C"],
                "330099": ["330099", "0062C4", "005D96", "00474B", "1931AE", "192E97", "192372", "444444", "403655"],
                "330066": ["330066", "00468B", "003F67", "212A2D", "192378", "191F66", "2A1549", "333333", "33283D"],
                "330033": ["330033", "002448", "131E30", "301517", "19123D", "230F31", "310A25", "222222", "251B25"],
                "330000": ["330000", "1E1B08", "221A00", "330600", "280D04", "2A0D00", "330300", "111111", "170D0D"],
                "00FFFF": ["00FFFF", "E6E4EE", "E6DCFF", "6EEFFF", "73F1F6", "73EDFF", "37F7FF", "AAAAAA", "88BBBB"],
                "00FFCC": ["00FFCC", "EDE1BD", "FBDAD4", "70EFFF", "76F0C4", "7DECD0", "38F7E5", "999999", "7AADA3"],
                "00FF99": ["00FF99", "F2DF8C", "FFD3A6", "72EEFF", "79EF92", "7FE99F", "39F6CC", "888888", "6C9F8B"],
                "00FF66": ["00FF66", "F5DD5C", "FFCF87", "73EEFF", "7AEE61", "7FE776", "39F6B2", "777777", "5F9273"],
                "00FF33": ["00FF33", "F6DD29", "FFCD77", "73EDFF", "7BEE2E", "7FE655", "39F699", "666666", "51845B"],
                "00FF00": ["00FF00", "F6DC00", "FFCD72", "73EDFF", "7BED00", "7FE639", "39F67F", "555555", "447744"],
                "00CCFF": ["00CCFF", "ADBAF2", "A5BBFF", "00D0DF", "56C3F8", "52C3FF", "00CEEF", "999999", "7AA3AD"],
                "00CCCC": ["00CCCC", "B8B6BF", "BBB3D1", "29CAD9", "5CC1C5", "5DBFCE", "14CBD2", "888888", "6C9595"],
                "00CC99": ["00CC99", "BFB38D", "CBAEA0", "47C4D3", "5FBF93", "65BD9C", "23C8B6", "777777", "5F887D"],
                "00CC66": ["00CC66", "C3B25D", "D4AA6F", "54C1CF", "61BF61", "6ABB6A", "2AC69A", "666666", "517A66"],
                "00CC33": ["00CC33", "C5B12B", "D9A844", "59BFCD", "62BE2F", "6CBA3B", "2CC580", "555555", "446C4E"],
                "00CC00": ["00CC00", "C5B000", "DAA831", "5ABFCD", "62BE00", "6DBA18", "2DC566", "444444", "365F36"],
                "0099FF": ["0099FF", "6792F8", "3398FF", "00ACB7", "3395FB", "1998FF", "00A2DB", "888888", "6C8B9F"],
                "0099CC": ["0099CC", "7E8DC2", "728ECF", "00A1AC", "3F93C7", "3993CD", "009DBC", "777777", "5F7D88"],
                "009999": ["009999", "8A898F", "8D869D", "1F97A3", "459194", "468F9B", "0F989E", "666666", "517070"],
                "009966": ["009966", "90865E", "9B816C", "39929D", "488F62", "4D8D69", "1C9581", "555555", "446258"],
                "009933": ["009933", "93852D", "A27E3D", "42909A", "498F30", "518B38", "219466", "444444", "365540"],
                "009900": ["009900", "948500", "A37E25", "448F9A", "4A8F00", "518B12", "22944D", "333333", "284728"],
                "0066FF": ["0066FF", "007EFE", "0090EC", "00929A", "0072FE", "007BF5", "007CCC", "777777", "5F7392"],
                "0066CC": ["0066CC", "1A66CC", "0078C9", "00828A", "0D66CC", "006FCA", "0074AB", "666666", "51667A"],
                "006699": ["006699", "4E5F93", "3D629A", "00727A", "276296", "1E6499", "006C89", "555555", "445862"],
                "006666": ["006666", "5C5B5F", "5E5A69", "15656D", "2E6062", "2F6067", "0A6569", "444444", "364A4A"],
                "006633": ["006633", "61592E", "6A5538", "2A6068", "305F30", "355D35", "15634D", "333333", "283D33"],
                "006600": ["006600", "635800", "6D5418", "2D5F66", "315F00", "365D0C", "166233", "222222", "1B2F1B"],
                "0033FF": ["0033FF", "5B91FF", "008CE2", "008389", "2D62FF", "005FF0", "005BC4", "666666", "515B84"],
                "0033CC": ["0033CC", "006FDE", "0078C2", "006F74", "0051D5", "0055C7", "0051A0", "555555", "444E6C"],
                "003399": ["003399", "0053A6", "005E9A", "00595E", "00439F", "004899", "00467B", "444444", "364055"],
                "003366": ["003366", "0D3366", "003E68", "004347", "063366", "003867", "003B56", "333333", "28333D"],
                "003333": ["003333", "2E2E30", "2F2D34", "0A3236", "173031", "173033", "053234", "222222", "1B2525"],
                "003300": ["003300", "312C00", "362A0C", "173033", "182F00", "1B2E06", "0B3119", "111111", "0D170D"],
                "0000FF": ["0000FF", "719CFF", "008BDF", "007F85", "384EFF", "0045EF", "003FC2", "555555", "444477"],
                "0000CC": ["0000CC", "0078F0", "0076BE", "006A6E", "003CDE", "003BC5", "00359D", "444444", "36365F"],
                "000099": ["000099", "0060C1", "005E97", "005155", "0030AD", "002F98", "002877", "333333", "282847"],
                "000066": ["000066", "004487", "004168", "003739", "002276", "002067", "001B4F", "222222", "1B1B2F"],
                "000033": ["000033", "002346", "002135", "001C1D", "00113C", "001034", "000E28", "111111", "0D0D17"],
                "000000": ["000000", "000000", "000000", "000000", "000000", "000000", "000000", "000000", "000000"]
            }
        };
        this.Pantone = new N({
            "80": "F4ED7C",
            "101": "F4ED47",
            "102": "F9E814",
            "103": "C6AD0F",
            "104": "AD9B0C",
            "105": "82750F",
            "106": "F7E859",
            "107": "F9E526",
            "108": "F9DD16",
            "109": "F9D616",
            "110": "D8B511",
            "111": "AA930A",
            "112": "99840A",
            "113": "F9E55B",
            "114": "F9E24C",
            "115": "F9E04C",
            "116": "FCD116",
            "116 2X": "F7B50C",
            "117": "C6A00C",
            "118": "AA8E0A",
            "119": "897719",
            "120": "F9E27F",
            "1205": "F7E8AA",
            "121": "F9E070",
            "1215": "F9E08C",
            "122": "FCD856",
            "1225": "FFCC49",
            "123": "FFC61E",
            "1235": "FCB514",
            "124": "E0AA0F",
            "1245": "BF910C",
            "125": "B58C0A",
            "1255": "A37F14",
            "126": "A38205",
            "1265": "7C6316",
            "127": "F4E287",
            "128": "F4DB60",
            "129": "F2D13D",
            "130": "EAAF0F",
            "130 2X": "E2980",
            "131": "C6930A",
            "132": "9E7C0A",
            "133": "705B0A",
            "134": "FFD87F",
            "1345": "FFD691",
            "135": "FCC963",
            "1355": "FCCE87",
            "328": "FCBF49",
            "3285": "FCBA5E",
            "137": "FCA311",
            "1375": "F99B0C",
            "138": "D88C02",
            "1385": "CC7A02",
            "139": "AF7505",
            "1395": "996007",
            "140": "7A5B11",
            "1405": "6B4714",
            "141": "F2CE68",
            "142": "F2BF49",
            "143": "EFB22D",
            "144": "E28C05",
            "145": "C67F07",
            "146": "9E6B05",
            "147": "725E26",
            "148": "FFD69B",
            "1485": "FFB777",
            "149": "FCCC93",
            "1495": "FF993F",
            "150": "FCAD56",
            "1505": "F47C00",
            "151": "F77F00",
            "152": "DD7500",
            "1525": "B55400",
            "153": "BC6D0A",
            "1535": "8C4400",
            "154": "995905",
            "1545": "4C280F",
            "155": "F4DBAA",
            "1555": "F9BF9E",
            "156": "F2C68C",
            "1565": "FCA577",
            "157": "EDA04F",
            "1575": "FC8744",
            "158": "E87511",
            "1585": "F96B07",
            "159": "C66005",
            "1595": "D15B05",
            "160": "9E540A",
            "1605": "A04F11",
            "161": "633A11",
            "1615": "843F0F",
            "162": "F9C6AA",
            "1625": "F9A58C",
            "163": "FC9E70",
            "1635": "F98E6D",
            "164": "FC7F3F",
            "1645": "F97242",
            "165": "F96302",
            "165 2X": "EA4F00",
            "1655": "F95602",
            "166": "DD5900",
            "1665": "DD4F05",
            "167": "BC4F07",
            "1675": "A53F0F",
            "168": "6D3011",
            "1685": "843511",
            "169": "F9BAAA",
            "170": "F98972",
            "171": "F9603A",
            "172": "F74902",
            "173": "D14414",
            "174": "933311",
            "175": "6D3321",
            "176": "F9AFAD",
            "1765": "F99EA3",
            "1767": "F9B2B7",
            "177": "F9827F",
            "1775": "F9848E",
            "1777": "FC6675",
            "178": "F95E59",
            "1785": "FC4F59",
            "1787": "F43F4F",
            "1788": "EF2B2D",
            "1788 2X": "D6280",
            "179": "E23D28",
            "1795": "D62828",
            "1797": "CC2D30",
            "180": "C13828",
            "1805": "AF2626",
            "1807": "A03033",
            "181": "7C2D23",
            "1810": "7C211E",
            "1817": "5B2D28",
            "182": "F9BFC1",
            "183": "FC8C99",
            "184": "FC5E72",
            "185": "E8112D",
            "185 2X": "D11600",
            "186": "CE1126",
            "187": "AF1E2D",
            "188": "7C2128",
            "189": "FFA3B2",
            "1895": "FCBFC9",
            "190": "FC758E",
            "1905": "FC9BB2",
            "191": "F4476B",
            "1915": "F4547C",
            "192": "E5053A",
            "1925": "E00747",
            "193": "DB828C",
            "1935": "C10538",
            "194": "992135",
            "1945": "A80C35",
            "1955": "931638",
            "196": "F4C9C9",
            "197": "EF99A3",
            "198": "772D35",
            "199": "D81C3F",
            "200": "C41E3A",
            "201": "A32638",
            "202": "8C2633",
            "203": "F2AFC1",
            "204": "ED7A9E",
            "205": "E54C7C",
            "206": "D30547",
            "207": "BAAA9E",
            "208": "8E2344",
            "209": "75263D",
            "210": "FFA0BF",
            "211": "FF77A8",
            "212": "F94F8E",
            "213": "EA0F6B",
            "214": "CC0256",
            "215": "A50544",
            "216": "7C1E3F",
            "217": "F4BFD1",
            "218": "ED72AA",
            "219": "E23282",
            "220": "AA004F",
            "221": "930042",
            "222": "70193D",
            "223": "F993C4",
            "224": "F46BAF",
            "225": "ED2893",
            "226": "D60270",
            "227": "AD005B",
            "228": "8C004C",
            "229": "6D213F",
            "230": "FFA0CC",
            "231": "FC70BA",
            "232": "F43FA5",
            "233": "CE007C",
            "234": "AA0066",
            "235": "8E0554",
            "236": "F9AFD3",
            "2365": "F7C4D8",
            "237": "F484C4",
            "2375": "EA6BBF",
            "238": "ED4FAF",
            "2385": "DB28A5",
            "239": "E0219E",
            "239 2X": "C4057C",
            "2395": "C4008C",
            "240": "C40F89",
            "2405": "A8007A",
            "241": "AD0075",
            "2415": "9B0070",
            "242": "7C1C51",
            "2425": "87005B",
            "243": "F2BAD8",
            "244": "EDA0D3",
            "245": "E87FC9",
            "246": "CC00A0",
            "247": "B7008E",
            "248": "A3057F",
            "249": "7F2860",
            "250": "EDC4DD",
            "251": "E29ED6",
            "252": "D36BC6",
            "253": "AF23A5",
            "254": "A02D96",
            "255": "772D6B",
            "256": "E5C4D6",
            "2562": "D8A8D8",
            "2563": "D1A0CC",
            "2567": "BF93CC",
            "257": "D3A5C9",
            "2572": "C687D1",
            "2573": "BA7CBC",
            "2577": "AA72BF",
            "258": "9B4F96",
            "2582": "AA47BA",
            "2583": "9E4FA5",
            "2587": "8E47AD",
            "259": "72166B",
            "2592": "930FA5",
            "2592 2X": "720082",
            "2593": "872B93",
            "2597": "66008C",
            "260": "681E5B",
            "2602": "820C8E",
            "2603": "70147A",
            "2607": "5B027A",
            "261": "5E2154",
            "2612": "701E72",
            "2613": "66116D",
            "2617": "560C70",
            "262": "542344",
            "2622": "602D59",
            "2623": "5B195E",
            "2627": "4C145E",
            "263": "E0CEE0",
            "2635": "C9ADD8",
            "264": "C6AADB",
            "2645": "B591D1",
            "265": "9663C4",
            "2655": "9B6DC6",
            "266": "6D28AA",
            "2665": "894FBF",
            "267": "59118E",
            "268": "4F2170",
            "2685": "56008C",
            "269": "442359",
            "2695": "44235E",
            "270": "BAAFD3",
            "2705": "AD9ED3",
            "2706": "D1CEDD",
            "2707": "BFD1E5",
            "2708": "AFBCDB",
            "271": "9E91C6",
            "2715": "937ACC",
            "2716": "A5A0D6",
            "2717": "A5BAE0",
            "2718": "5B77CC",
            "272": "8977BA",
            "2725": "7251BC",
            "2726": "6656BC",
            "2727": "5E68C4",
            "2728": "3044B5",
            "273": "38197A",
            "2735": "4F0093",
            "2736": "4930AD",
            "2738": "2D008E",
            "274": "2B1166",
            "2745": "3F0077",
            "2746": "3F2893",
            "2747": "1C146B",
            "2748": "1E1C77",
            "275": "260F54",
            "2755": "35006D",
            "2756": "332875",
            "2757": "141654",
            "2758": "192168",
            "276": "2B2147",
            "2765": "2B0C56",
            "2766": "2B265B",
            "2767": "14213D",
            "2768": "112151",
            "277": "B5D1E8",
            "278": "99BADD",
            "279": "6689CC",
            "280": "002B7F",
            "281": "002868",
            "282": "002654",
            "283": "9BC4E2",
            "284": "75AADB",
            "285": "3A75C4",
            "286": "0038A8",
            "287": "003893",
            "328": "00337F",
            "289": "002649",
            "290": "C4D8E2",
            "2905": "93C6E0",
            "291": "A8CEE2",
            "2915": "60AFDD",
            "292": "75B2DD",
            "2925": "008ED6",
            "293": "0051BA",
            "2935": "005BBF",
            "294": "003F87",
            "2945": "0054A0",
            "295": "00386B",
            "2955": "003D6B",
            "296": "002D47",
            "2965": "00334C",
            "297": "82C6E2",
            "2975": "BAE0E2",
            "298": "51B5E0",
            "2985": "51BFE2",
            "299": "00A3DD",
            "299 2X": "007FCC",
            "2995": "00A5DB",
            "300": "0072C6",
            "3005": "0084C9",
            "301": "005B99",
            "3015": "00709E",
            "302": "004F6D",
            "3025": "00546B",
            "303": "003F54",
            "3035": "004454",
            "304": "A5DDE2",
            "305": "70CEE2",
            "306": "00BCE2",
            "306 2X": "00A3D1",
            "307": "007AA5",
            "308": "00607C",
            "309": "003F49",
            "310": "72D1DD",
            "3105": "7FD6DB",
            "311": "28C4D8",
            "3115": "2DC6D6",
            "312": "00ADC6",
            "3125": "00B7C6",
            "313": "0099B5",
            "3135": "009BAA",
            "314": "00829B",
            "3145": "00848E",
            "315": "006B77",
            "3155": "006D75",
            "316": "00494F",
            "3165": "00565B",
            "317": "C9E8DD",
            "318": "93DDDB",
            "319": "4CCED1",
            "320": "009EA0",
            "320 2X": "007F82",
            "321": "008789",
            "322": "007272",
            "323": "006663",
            "324": "AADDD6",
            "3242": "87DDD1",
            "3245": "8CE0D1",
            "3248": "7AD3C1",
            "325": "56C9C1",
            "3252": "56D6C9",
            "3255": "47D6C1",
            "3258": "35C4AF",
            "326": "00B2AA",
            "3262": "00C1B5",
            "3265": "00C6B2",
            "3268": "00AF99",
            "327": "008C82",
            "327 2X": "008977",
            "3272": "00AA9E",
            "3275": "00B2A0",
            "3278": "009B84",
            "328": "007770",
            "3282": "008C82",
            "3285": "009987",
            "3328": "008270",
            "329": "006D66",
            "3292": "006056",
            "3295": "008272",
            "3298": "006B5B",
            "330": "005951",
            "3302": "00493F",
            "3305": "004F42",
            "3308": "004438",
            "331": "BAEAD6",
            "332": "A0E5CE",
            "333": "5EDDC1",
            "334": "00997C",
            "335": "007C66",
            "336": "006854",
            "337": "9BDBC1",
            "3375": "8EE2BC",
            "338": "7AD1B5",
            "3385": "54D8A8",
            "339": "00B28C",
            "3395": "00C993",
            "340": "009977",
            "3405": "00B27A",
            "341": "007A5E",
            "3415": "007C59",
            "342": "006B54",
            "3425": "006847",
            "343": "00563F",
            "3435": "024930",
            "344": "B5E2BF",
            "345": "96D8AF",
            "346": "70CE9B",
            "347": "009E60",
            "348": "008751",
            "349": "006B3F",
            "350": "234F33",
            "351": "B5E8BF",
            "352": "99E5B2",
            "353": "84E2A8",
            "354": "00B760",
            "355": "009E49",
            "356": "007A3D",
            "357": "215B33",
            "358": "AADD96",
            "359": "A0DB8E",
            "360": "60C659",
            "361": "1EB53A",
            "362": "339E35",
            "363": "3D8E33",
            "364": "3A7728",
            "365": "D3E8A3",
            "366": "C4E58E",
            "367": "AADD6D",
            "368": "5BBF21",
            "368 2X": "009E0F",
            "369": "56AA1C",
            "370": "568E14",
            "371": "566B21",
            "372": "D8ED96",
            "373": "CEEA82",
            "374": "BAE860",
            "375": "8CD600",
            "375 2X": "54BC00",
            "376": "7FBA00",
            "377": "709302",
            "378": "566314",
            "379": "E0EA68",
            "380": "D6E542",
            "381": "CCE226",
            "382": "BAD80A",
            "382 2X": "9EC400",
            "383": "A3AF07",
            "384": "939905",
            "385": "707014",
            "386": "E8ED60",
            "387": "E0ED44",
            "388": "D6E80F",
            "389": "CEE007",
            "390": "BAC405",
            "391": "9E9E07",
            "392": "848205",
            "393": "F2EF87",
            "3935": "F2ED6D",
            "394": "EAED35",
            "3945": "EFEA07",
            "395": "E5E811",
            "3955": "EDE211",
            "396": "E0E20C",
            "3965": "E8DD11",
            "397": "C1BF0A",
            "3975": "B5A80C",
            "398": "AFA80A",
            "3985": "998C0A",
            "399": "998E07",
            "3995": "6D6002",
            "400": "D1C6B5",
            "401": "C1B5A5",
            "402": "AFA593",
            "403": "998C7C",
            "404": "827566",
            "405": "6B5E4F",
            "406": "CEC1B5",
            "408": "A8998C",
            "409": "99897C",
            "410": "7C6D63",
            "411": "66594C",
            "412": "3D3028",
            "413": "C6C1B2",
            "414": "B5AFA0",
            "415": "A39E8C",
            "416": "8E8C7A",
            "417": "777263",
            "418": "605E4F",
            "419": "282821",
            "420": "D1CCBF",
            "421": "BFBAAF",
            "422": "AFAAA3",
            "423": "96938E",
            "424": "827F77",
            "425": "60605B",
            "426": "2B2B28",
            "427": "DDDBD1",
            "428": "D1CEC6",
            "429": "ADAFAA",
            "430": "919693",
            "431": "666D70",
            "432": "444F51",
            "433": "30383A",
            "433 2X": "0A0C11",
            "434": "E0D1C6",
            "435": "D3BFB7",
            "436": "BCA59E",
            "437": "8C706B",
            "438": "593F3D",
            "439": "493533",
            "440": "3F302B",
            "441": "D1D1C6",
            "442": "BABFB7",
            "443": "A3A8A3",
            "444": "898E8C",
            "445": "565959",
            "446": "494C49",
            "447": "3F3F38",
            "448": "54472D",
            "4485": "604C11",
            "449": "544726",
            "4495": "877530",
            "450": "60542B",
            "4505": "A09151",
            "451": "ADA07A",
            "4515": "BCAD75",
            "452": "C4B796",
            "452 2X": "009944",
            "4525": "CCBF8E",
            "453": "D6CCAF",
            "4535": "DBCEA5",
            "454": "E2D8BF",
            "4545": "E5DBBA",
            "455": "665614",
            "456": "998714",
            "457": "B59B0C",
            "458": "DDCC6B",
            "459": "E2D67C",
            "460": "EADD96",
            "461": "EDE5AD",
            "462": "5B4723",
            "4625": "472311",
            "463": "755426",
            "4635": "8C5933",
            "464": "876028",
            "464 2X": "704214",
            "4645": "B28260",
            "465": "C1A875",
            "4655": "C49977",
            "466": "D1BF91",
            "4665": "D8B596",
            "467": "DDCCA5",
            "4675": "E5C6AA",
            "468": "E2D6B5",
            "4685": "EDD3BC",
            "469": "603311",
            "4695": "51261C",
            "470": "9B4F19",
            "4705": "7C513D",
            "471": "BC5E1E",
            "471 2X": "A34402",
            "4715": "99705B",
            "472": "EAAA7A",
            "4725": "B5917C",
            "473": "F4C4A0",
            "4735": "CCAF9B",
            "474": "F4CCAA",
            "4745": "D8BFAA",
            "475": "F7D3B5",
            "4755": "E2CCBA",
            "476": "593D2B",
            "477": "633826",
            "478": "7A3F28",
            "479": "AF8970",
            "480": "D3B7A3",
            "481": "E0CCBA",
            "482": "E5D3C1",
            "483": "6B3021",
            "484": "9B301C",
            "485": "D81E05",
            "485 2X": "CC0C00",
            "486": "ED9E84",
            "487": "EFB5A0",
            "488": "F2C4AF",
            "489": "F2D1BF",
            "490": "5B2626",
            "491": "752828",
            "492": "913338",
            "494": "F2ADB2",
            "495": "F4BCBF",
            "496": "F7C9C6",
            "497": "512826",
            "4975": "441E1C",
            "498": "6D332B",
            "4985": "844949",
            "499": "7A382D",
            "4995": "A56B6D",
            "500": "CE898C",
            "5005": "BC8787",
            "501": "EAB2B2",
            "5015": "D8ADA8",
            "502": "F2C6C4",
            "5025": "E2BCB7",
            "503": "F4D1CC",
            "5035": "EDCEC6",
            "504": "511E26",
            "505": "661E2B",
            "506": "7A2638",
            "507": "D8899B",
            "508": "E8A5AF",
            "509": "F2BABF",
            "510": "F4C6C9",
            "511": "602144",
            "5115": "4F213A",
            "512": "84216B",
            "5125": "754760",
            "513": "9E2387",
            "5135": "936B7F",
            "514": "D884BC",
            "5145": "AD8799",
            "515": "E8A3C9",
            "5155": "CCAFB7",
            "516": "F2BAD3",
            "5165": "E0C9CC",
            "517": "F4CCD8",
            "5175": "E8D6D1",
            "518": "512D44",
            "5185": "472835",
            "519": "63305E",
            "5195": "593344",
            "520": "703572",
            "5205": "8E6877",
            "521": "B58CB2",
            "5215": "B5939B",
            "522": "C6A3C1",
            "5225": "CCADAF",
            "523": "D3B7CC",
            "5235": "DDC6C4",
            "524": "E2CCD3",
            "5245": "E5D3CC",
            "525": "512654",
            "5255": "35264F",
            "526": "68217A",
            "5265": "493D63",
            "527": "7A1E99",
            "5275": "605677",
            "528": "AF72C1",
            "5285": "8C8299",
            "529": "CEA3D3",
            "5295": "B2A8B5",
            "530": "D6AFD6",
            "5305": "CCC1C6",
            "531": "E5C6DB",
            "5315": "DBD3D3",
            "532": "353842",
            "533": "353F5B",
            "534": "3A4972",
            "535": "9BA3B7",
            "536": "ADB2C1",
            "537": "C4C6CE",
            "538": "D6D3D6",
            "539": "003049",
            "5395": "02283A",
            "540": "00335B",
            "5405": "3F6075",
            "541": "003F77",
            "5415": "607C8C",
            "542": "6693BC",
            "5425": "8499A5",
            "543": "93B7D1",
            "5435": "AFBCBF",
            "544": "B7CCDB",
            "5445": "C4CCCC",
            "545": "C4D3DD",
            "5455": "D6D8D3",
            "546": "0C3844",
            "5463": "00353A",
            "5467": "193833",
            "547": "003F54",
            "5473": "26686D",
            "5477": "3A564F",
            "548": "004459",
            "5483": "609191",
            "5487": "667C72",
            "549": "5E99AA",
            "5493": "8CAFAD",
            "5497": "91A399",
            "550": "87AFBF",
            "5503": "AAC4BF",
            "5507": "AFBAB2",
            "551": "A3C1C9",
            "5513": "CED8D1",
            "5517": "C9CEC4",
            "552": "C4D6D6",
            "5523": "D6DDD6",
            "5527": "CED1C6",
            "553": "234435",
            "5535": "213D30",
            "554": "195E47",
            "5545": "4F6D5E",
            "555": "076D54",
            "5555": "779182",
            "556": "7AA891",
            "5565": "96AA99",
            "557": "A3C1AD",
            "5575": "AFBFAD",
            "558": "B7CEBC",
            "5585": "C4CEBF",
            "559": "C6D6C4",
            "5595": "D8DBCC",
            "560": "2B4C3F",
            "5605": "233A2D",
            "561": "266659",
            "5615": "546856",
            "562": "1E7A6D",
            "5625": "728470",
            "563": "7FBCAA",
            "5635": "9EAA99",
            "564": "05705E",
            "5645": "BCC1B2",
            "565": "BCDBCC",
            "5655": "C6CCBA",
            "566": "D1E2D3",
            "5665": "D6D6C6",
            "567": "265142",
            "569": "008772",
            "570": "7FC6B2",
            "571": "AADBC6",
            "572": "BCE2CE",
            "573": "CCE5D6",
            "574": "495928",
            "5743": "3F4926",
            "5747": "424716",
            "575": "547730",
            "5753": "5E663A",
            "5757": "6B702B",
            "576": "608E3A",
            "5763": "777C4F",
            "5767": "8C914F",
            "577": "B5CC8E",
            "5773": "9B9E72",
            "5777": "AAAD75",
            "578": "C6D6A0",
            "5783": "B5B58E",
            "5787": "C6C699",
            "579": "C9D6A3",
            "5793": "C6C6A5",
            "5797": "D3D1AA",
            "580": "D8DDB5",
            "5803": "D8D6B7",
            "5807": "E0DDBC",
            "581": "605E11",
            "5815": "494411",
            "582": "878905",
            "5825": "75702B",
            "583": "AABA0A",
            "5835": "9E9959",
            "584": "CED649",
            "5845": "B2AA70",
            "585": "DBE06B",
            "5855": "CCC693",
            "586": "E2E584",
            "5865": "D6CEA3",
            "587": "E8E89B",
            "5875": "E0DBB5",
            "600": "F4EDAF",
            "601": "F2ED9E",
            "602": "F2EA87",
            "603": "EDE85B",
            "604": "E8DD21",
            "605": "DDCE11",
            "606": "D3BF11",
            "607": "F2EABC",
            "608": "EFE8AD",
            "609": "EAE596",
            "610": "E2DB72",
            "611": "D6CE49",
            "612": "C4BA00",
            "613": "AFA00C",
            "614": "EAE2B7",
            "615": "E2DBAA",
            "616": "DDD69B",
            "617": "CCC47C",
            "618": "B5AA59",
            "619": "968C28",
            "620": "847711",
            "621": "D8DDCE",
            "622": "C1D1BF",
            "623": "A5BFAA",
            "624": "7FA08C",
            "625": "5B8772",
            "626": "21543F",
            "627": "0C3026",
            "628": "CCE2DD",
            "629": "B2D8D8",
            "630": "8CCCD3",
            "631": "54B7C6",
            "632": "00A0BA",
            "633": "007F99",
            "634": "00667F",
            "635": "BAE0E0",
            "636": "99D6DD",
            "637": "6BC9DB",
            "638": "00B5D6",
            "639": "00A0C4",
            "640": "008CB2",
            "641": "007AA5",
            "642": "D1D8D8",
            "643": "C6D1D6",
            "644": "9BAFC4",
            "645": "7796B2",
            "646": "5E82A3",
            "647": "26547C",
            "648": "00305E",
            "649": "D6D6D8",
            "650": "BFC6D1",
            "651": "9BAABF",
            "652": "6D87A8",
            "653": "335687",
            "654": "0F2B5B",
            "655": "0C1C47",
            "656": "D6DBE0",
            "657": "C1C9DD",
            "658": "A5AFD6",
            "659": "7F8CBF",
            "660": "5960A8",
            "661": "2D338E",
            "662": "0C1975",
            "663": "E2D3D6",
            "664": "D8CCD1",
            "665": "C6B5C4",
            "666": "A893AD",
            "667": "7F6689",
            "668": "664975",
            "669": "472B59",
            "670": "F2D6D8",
            "671": "EFC6D3",
            "672": "EAAAC4",
            "673": "E08CB2",
            "674": "D36B9E",
            "675": "BC3877",
            "676": "A00054",
            "677": "EDD6D6",
            "678": "EACCCE",
            "679": "E5BFC6",
            "680": "D39EAF",
            "681": "B7728E",
            "682": "A05175",
            "683": "7F284F",
            "684": "EFCCCE",
            "685": "EABFC4",
            "686": "E0AABA",
            "687": "C9899E",
            "688": "B26684",
            "689": "934266",
            "690": "702342",
            "691": "EFD1C9",
            "692": "E8BFBA",
            "693": "DBA8A5",
            "694": "C98C8C",
            "695": "B26B70",
            "696": "8E4749",
            "697": "7F383A",
            "698": "F7D1CC",
            "699": "F7BFBF",
            "700": "F2A5AA",
            "701": "E8878E",
            "702": "D6606D",
            "703": "B73844",
            "704": "9E2828",
            "705": "F9DDD6",
            "706": "FCC9C6",
            "707": "FCADAF",
            "708": "F98E99",
            "709": "F26877",
            "710": "E04251",
            "711": "D12D33",
            "712": "FFD3AA",
            "713": "F9C9A3",
            "714": "F9BA82",
            "715": "FC9E49",
            "716": "F28411",
            "717": "D36D00",
            "718": "BF5B00",
            "719": "F4D1AF",
            "720": "EFC49E",
            "721": "E8B282",
            "722": "D18E54",
            "723": "BA7530",
            "724": "8E4905",
            "725": "753802",
            "726": "EDD3B5",
            "727": "E2BF9B",
            "728": "D3A87C",
            "729": "C18E60",
            "730": "AA753F",
            "731": "723F0A",
            "732": "60330A",
            "801": "00AACC",
            "801 2X": "0089AF",
            "802": "60DD49",
            "802 2X": "1CCE28",
            "803": "FFED38",
            "803 2X": "FFD816",
            "804": "FF9338",
            "804 2X": "FF7F1E",
            "805": "F95951",
            "805 2X": "F93A2B",
            "806": "FF0093",
            "806 2X": "F7027C",
            "807": "D6009E",
            "807 2X": "BF008C",
            "808": "00B59B",
            "808 2X": "00A087",
            "809": "DDE00F",
            "809 2X": "D6D60C",
            "810": "FFCC1E",
            "810 2X": "FFBC21",
            "811": "FF7247",
            "811 2X": "FF5416",
            "812": "FC2366",
            "812 2X": "FC074F",
            "813": "E50099",
            "813 2X": "D10084",
            "814": "8C60C1",
            "814 2X": "703FAF",
            White: "FFFFFF",
            Black: "000000"
        });
        this.Pantone.init = function () {
            var a, c, e, h;
            this.Data = {};
            for (a in this.SourceData) {
                c = this.SourceData[a];
                if (c = f(c)) {
                    e = I.getColorByRGB(c);
                    h = a;
                    if (h != "White" && h != "Black") h = "Pantone " + h;
                    this.Data[a] = {
                        Name: h,
                        RGB: c,
                        HSV: e
                    };
                    this.indexByHue(a)
                }
            }
            this.Inited = true
        };
        this.RAL = new N({
            "1000": {
                Name2: "Green beige",
                RGB: {
                    R: 214,
                    G: 199,
                    B: 148
                }
            },
            "1001": {
                Name2: "Beige",
                RGB: {
                    R: 217,
                    G: 186,
                    B: 140
                }
            },
            "1002": {
                Name2: "Sand yellow",
                RGB: {
                    R: 214,
                    G: 176,
                    B: 117
                }
            },
            "1003": {
                Name2: "Signal yellow",
                RGB: {
                    R: 252,
                    G: 163,
                    B: 41
                }
            },
            "1004": {
                Name2: "Golden yellow",
                RGB: {
                    R: 227,
                    G: 150,
                    B: 36
                }
            },
            "1005": {
                Name2: "Honey yellow",
                RGB: {
                    R: 201,
                    G: 135,
                    B: 33
                }
            },
            "1006": {
                Name2: "Maize yellow",
                RGB: {
                    R: 224,
                    G: 130,
                    B: 31
                }
            },
            "1007": {
                Name2: "Daffodil yellow",
                RGB: {
                    R: 227,
                    G: 122,
                    B: 31
                }
            },
            "1011": {
                Name2: "Brown beige",
                RGB: {
                    R: 173,
                    G: 122,
                    B: 79
                }
            },
            "1012": {
                Name2: "Lemon yellow",
                RGB: {
                    R: 227,
                    G: 184,
                    B: 56
                }
            },
            "1013": {
                Name2: "Oyster white",
                RGB: {
                    R: 255,
                    G: 245,
                    B: 227
                }
            },
            "1014": {
                Name2: "Ivory",
                RGB: {
                    R: 240,
                    G: 214,
                    B: 171
                }
            },
            "1015": {
                Name2: "Light ivory",
                RGB: {
                    R: 252,
                    G: 235,
                    B: 204
                }
            },
            "1016": {
                Name2: "Sulfur yellow",
                RGB: {
                    R: 255,
                    G: 245,
                    B: 66
                }
            },
            "1017": {
                Name2: "Saffron yellow",
                RGB: {
                    R: 255,
                    G: 171,
                    B: 89
                }
            },
            "1018": {
                Name2: "Zinc yellow",
                RGB: {
                    R: 255,
                    G: 214,
                    B: 77
                }
            },
            "1019": {
                Name2: "Grey beige",
                RGB: {
                    R: 163,
                    G: 140,
                    B: 122
                }
            },
            "1020": {
                Name2: "Olive yellow",
                RGB: {
                    R: 156,
                    G: 143,
                    B: 97
                }
            },
            "1021": {
                Name2: "Rape yellow",
                RGB: {
                    R: 252,
                    G: 189,
                    B: 31
                }
            },
            "1023": {
                Name2: "Traffic yellow",
                RGB: {
                    R: 252,
                    G: 184,
                    B: 33
                }
            },
            "1024": {
                Name2: "Ochre yellow",
                RGB: {
                    R: 181,
                    G: 140,
                    B: 79
                }
            },
            "1026": {
                Name2: "Luminous yellow",
                RGB: {
                    R: 255,
                    G: 255,
                    B: 10
                }
            },
            "1027": {
                Name2: "Curry",
                RGB: {
                    R: 153,
                    G: 117,
                    B: 33
                }
            },
            "1028": {
                Name2: "Melon yellow",
                RGB: {
                    R: 255,
                    G: 140,
                    B: 26
                }
            },
            "1032": {
                Name2: "Broom yellow",
                RGB: {
                    R: 227,
                    G: 163,
                    B: 41
                }
            },
            "1033": {
                Name2: "Dahlia yellow",
                RGB: {
                    R: 255,
                    G: 148,
                    B: 54
                }
            },
            "1034": {
                Name2: "Pastel yellow",
                RGB: {
                    R: 247,
                    G: 153,
                    B: 92
                }
            },
            "2000": {
                Name2: "Yellow orange",
                RGB: {
                    R: 224,
                    G: 94,
                    B: 31
                }
            },
            "2001": {
                Name2: "Red orange",
                RGB: {
                    R: 186,
                    G: 46,
                    B: 33
                }
            },
            "2002": {
                Name2: "Vermilion",
                RGB: {
                    R: 204,
                    G: 36,
                    B: 28
                }
            },
            "2003": {
                Name2: "Pastel orange",
                RGB: {
                    R: 255,
                    G: 99,
                    B: 54
                }
            },
            "2004": {
                Name2: "Pure orange",
                RGB: {
                    R: 242,
                    G: 59,
                    B: 28
                }
            },
            "2005": {
                Name2: "Luminous orange",
                RGB: {
                    R: 252,
                    G: 28,
                    B: 20
                }
            },
            "2007": {
                Name2: "Luminous bright orange",
                RGB: {
                    R: 255,
                    G: 117,
                    B: 33
                }
            },
            "2008": {
                Name2: "Bright red orange",
                RGB: {
                    R: 250,
                    G: 79,
                    B: 41
                }
            },
            "2009": {
                Name2: "Traffic orange",
                RGB: {
                    R: 235,
                    G: 59,
                    B: 28
                }
            },
            "2010": {
                Name2: "Signal orange",
                RGB: {
                    R: 212,
                    G: 69,
                    B: 41
                }
            },
            "2011": {
                Name2: "Deep orange",
                RGB: {
                    R: 237,
                    G: 92,
                    B: 41
                }
            },
            "2012": {
                Name2: "Salmon orange",
                RGB: {
                    R: 222,
                    G: 82,
                    B: 71
                }
            },
            "3000": {
                Name2: "Flame red",
                RGB: {
                    R: 171,
                    G: 31,
                    B: 28
                }
            },
            "3001": {
                Name2: "Signal red",
                RGB: {
                    R: 163,
                    G: 23,
                    B: 26
                }
            },
            "3002": {
                Name2: "Carmine red",
                RGB: {
                    R: 163,
                    G: 26,
                    B: 26
                }
            },
            "3003": {
                Name2: "Ruby red",
                RGB: {
                    R: 138,
                    G: 18,
                    B: 20
                }
            },
            "3004": {
                Name2: "Purple red",
                RGB: {
                    R: 105,
                    G: 15,
                    B: 20
                }
            },
            "3005": {
                Name2: "Wine red",
                RGB: {
                    R: 79,
                    G: 18,
                    B: 26
                }
            },
            "3007": {
                Name2: "Black red",
                RGB: {
                    R: 46,
                    G: 18,
                    B: 26
                }
            },
            "3009": {
                Name2: "Oxide red",
                RGB: {
                    R: 94,
                    G: 33,
                    B: 33
                }
            },
            "3011": {
                Name2: "Brown red",
                RGB: {
                    R: 120,
                    G: 20,
                    B: 23
                }
            },
            "3012": {
                Name2: "Beige red",
                RGB: {
                    R: 204,
                    G: 130,
                    B: 115
                }
            },
            "3013": {
                Name2: "Tomato red",
                RGB: {
                    R: 150,
                    G: 31,
                    B: 28
                }
            },
            "3014": {
                Name2: "Antique pink",
                RGB: {
                    R: 217,
                    G: 102,
                    B: 117
                }
            },
            "3015": {
                Name2: "Light pink",
                RGB: {
                    R: 232,
                    G: 156,
                    B: 181
                }
            },
            "3016": {
                Name2: "Coral red",
                RGB: {
                    R: 166,
                    G: 36,
                    B: 38
                }
            },
            "3017": {
                Name2: "Rose",
                RGB: {
                    R: 209,
                    G: 54,
                    B: 84
                }
            },
            "3018": {
                Name2: "Strawberry red",
                RGB: {
                    R: 207,
                    G: 41,
                    B: 66
                }
            },
            "3020": {
                Name2: "Traffic red",
                RGB: {
                    R: 199,
                    G: 23,
                    B: 18
                }
            },
            "3022": {
                Name2: "Salmon pink",
                RGB: {
                    R: 217,
                    G: 89,
                    B: 79
                }
            },
            "3024": {
                Name2: "Luminous red",
                RGB: {
                    R: 252,
                    G: 10,
                    B: 28
                }
            },
            "3026": {
                Name2: "Luminous bright red",
                RGB: {
                    R: 252,
                    G: 20,
                    B: 20
                }
            },
            "3027": {
                Name2: "Raspberry red",
                RGB: {
                    R: 181,
                    G: 18,
                    B: 51
                }
            },
            "3031": {
                Name2: "Orient red",
                RGB: {
                    R: 166,
                    G: 28,
                    B: 46
                }
            },
            "4001": {
                Name2: "Red lilac",
                RGB: {
                    R: 130,
                    G: 64,
                    B: 128
                }
            },
            "4002": {
                Name2: "Red violet",
                RGB: {
                    R: 143,
                    G: 38,
                    B: 64
                }
            },
            "4003": {
                Name2: "Heather violet",
                RGB: {
                    R: 201,
                    G: 56,
                    B: 140
                }
            },
            "4004": {
                Name2: "Claret violet",
                RGB: {
                    R: 92,
                    G: 8,
                    B: 43
                }
            },
            "4005": {
                Name2: "Blue lilac",
                RGB: {
                    R: 99,
                    G: 61,
                    B: 156
                }
            },
            "4006": {
                Name2: "Traffic purple",
                RGB: {
                    R: 145,
                    G: 15,
                    B: 102
                }
            },
            "4007": {
                Name2: "Purple violet",
                RGB: {
                    R: 56,
                    G: 10,
                    B: 46
                }
            },
            "4008": {
                Name2: "Signal violet",
                RGB: {
                    R: 125,
                    G: 31,
                    B: 122
                }
            },
            "4009": {
                Name2: "Pastel violet",
                RGB: {
                    R: 158,
                    G: 115,
                    B: 148
                }
            },
            "4010": {
                Name2: "Telemagenta",
                RGB: {
                    R: 191,
                    G: 23,
                    B: 115
                }
            },
            "5000": {
                Name2: "Violet blue",
                RGB: {
                    R: 23,
                    G: 51,
                    B: 107
                }
            },
            "5001": {
                Name2: "Green blue",
                RGB: {
                    R: 10,
                    G: 51,
                    B: 84
                }
            },
            "5002": {
                Name2: "Ultramarine blue",
                RGB: {
                    R: 0,
                    G: 15,
                    B: 117
                }
            },
            "5003": {
                Name2: "Sapphire blue",
                RGB: {
                    R: 0,
                    G: 23,
                    B: 69
                }
            },
            "5004": {
                Name2: "Black blue",
                RGB: {
                    R: 3,
                    G: 13,
                    B: 31
                }
            },
            "5005": {
                Name2: "Signal blue",
                RGB: {
                    R: 0,
                    G: 46,
                    B: 122
                }
            },
            "5007": {
                Name2: "Brillant blue",
                RGB: {
                    R: 38,
                    G: 79,
                    B: 135
                }
            },
            "5008": {
                Name2: "Gray blue",
                RGB: {
                    R: 26,
                    G: 41,
                    B: 56
                }
            },
            "5009": {
                Name2: "Azure blue",
                RGB: {
                    R: 23,
                    G: 69,
                    B: 112
                }
            },
            "5010": {
                Name2: "Gentian blue",
                RGB: {
                    R: 0,
                    G: 43,
                    B: 112
                }
            },
            "5011": {
                Name2: "Steel blue",
                RGB: {
                    R: 3,
                    G: 20,
                    B: 46
                }
            },
            "5012": {
                Name2: "Light blue",
                RGB: {
                    R: 41,
                    G: 115,
                    B: 184
                }
            },
            "5013": {
                Name2: "Cobalt blue",
                RGB: {
                    R: 0,
                    G: 18,
                    B: 69
                }
            },
            "5014": {
                Name2: "Pigeon blue",
                RGB: {
                    R: 77,
                    G: 105,
                    B: 153
                }
            },
            "5015": {
                Name2: "Sky blue",
                RGB: {
                    R: 23,
                    G: 97,
                    B: 171
                }
            },
            "5017": {
                Name2: "Traffic blue",
                RGB: {
                    R: 0,
                    G: 59,
                    B: 128
                }
            },
            "5018": {
                Name2: "Turquoise blue",
                RGB: {
                    R: 56,
                    G: 148,
                    B: 130
                }
            },
            "5019": {
                Name2: "Capri blue",
                RGB: {
                    R: 10,
                    G: 66,
                    B: 120
                }
            },
            "5020": {
                Name2: "Ocean blue",
                RGB: {
                    R: 5,
                    G: 51,
                    B: 51
                }
            },
            "5021": {
                Name2: "Water blue",
                RGB: {
                    R: 26,
                    G: 122,
                    B: 99
                }
            },
            "5022": {
                Name2: "Night blue",
                RGB: {
                    R: 0,
                    G: 8,
                    B: 79
                }
            },
            "5023": {
                Name2: "Distant blue",
                RGB: {
                    R: 46,
                    G: 82,
                    B: 143
                }
            },
            "5024": {
                Name2: "Pastel blue",
                RGB: {
                    R: 87,
                    G: 140,
                    B: 181
                }
            },
            "6000": {
                Name2: "Patina green",
                RGB: {
                    R: 51,
                    G: 120,
                    B: 84
                }
            },
            "6001": {
                Name2: "Emerald green",
                RGB: {
                    R: 38,
                    G: 102,
                    B: 41
                }
            },
            "6002": {
                Name2: "Leaf green",
                RGB: {
                    R: 38,
                    G: 87,
                    B: 33
                }
            },
            "6003": {
                Name2: "Olive green",
                RGB: {
                    R: 61,
                    G: 69,
                    B: 46
                }
            },
            "6004": {
                Name2: "Blue green",
                RGB: {
                    R: 13,
                    G: 59,
                    B: 46
                }
            },
            "6005": {
                Name2: "Moss green",
                RGB: {
                    R: 10,
                    G: 56,
                    B: 31
                }
            },
            "6006": {
                Name2: "Grey olive",
                RGB: {
                    R: 41,
                    G: 43,
                    B: 36
                }
            },
            "6007": {
                Name2: "Bottle green",
                RGB: {
                    R: 28,
                    G: 38,
                    B: 23
                }
            },
            "6008": {
                Name2: "Brown green",
                RGB: {
                    R: 33,
                    G: 33,
                    B: 26
                }
            },
            "6009": {
                Name2: "Fir green",
                RGB: {
                    R: 23,
                    G: 41,
                    B: 28
                }
            },
            "6010": {
                Name2: "Grass green",
                RGB: {
                    R: 54,
                    G: 105,
                    B: 38
                }
            },
            "6011": {
                Name2: "Reseda green",
                RGB: {
                    R: 94,
                    G: 125,
                    B: 79
                }
            },
            "6012": {
                Name2: "Black green",
                RGB: {
                    R: 31,
                    G: 46,
                    B: 43
                }
            },
            "6013": {
                Name2: "Reed green",
                RGB: {
                    R: 117,
                    G: 115,
                    B: 79
                }
            },
            "6014": {
                Name2: "Yellow olive",
                RGB: {
                    R: 51,
                    G: 48,
                    B: 38
                }
            },
            "6015": {
                Name2: "Black olive",
                RGB: {
                    R: 41,
                    G: 43,
                    B: 38
                }
            },
            "6016": {
                Name2: "Turquoise green",
                RGB: {
                    R: 15,
                    G: 112,
                    B: 51
                }
            },
            "6017": {
                Name2: "Yellow green",
                RGB: {
                    R: 64,
                    G: 130,
                    B: 54
                }
            },
            "6018": {
                Name2: "May green",
                RGB: {
                    R: 79,
                    G: 168,
                    B: 51
                }
            },
            "6019": {
                Name2: "Pastel green",
                RGB: {
                    R: 191,
                    G: 227,
                    B: 186
                }
            },
            "6020": {
                Name2: "Chrome green",
                RGB: {
                    R: 38,
                    G: 56,
                    B: 41
                }
            },
            "6021": {
                Name2: "Pale green",
                RGB: {
                    R: 133,
                    G: 166,
                    B: 122
                }
            },
            "6022": {
                Name2: "Olive drab",
                RGB: {
                    R: 43,
                    G: 38,
                    B: 28
                }
            },
            "6024": {
                Name2: "Traffic green",
                RGB: {
                    R: 36,
                    G: 145,
                    B: 64
                }
            },
            "6025": {
                Name2: "Fern green",
                RGB: {
                    R: 74,
                    G: 110,
                    B: 51
                }
            },
            "6026": {
                Name2: "Opal green",
                RGB: {
                    R: 10,
                    G: 92,
                    B: 51
                }
            },
            "6027": {
                Name2: "Light green",
                RGB: {
                    R: 125,
                    G: 204,
                    B: 189
                }
            },
            "6028": {
                Name2: "Pine green",
                RGB: {
                    R: 38,
                    G: 74,
                    B: 51
                }
            },
            "6029": {
                Name2: "Mint green",
                RGB: {
                    R: 18,
                    G: 120,
                    B: 38
                }
            },
            "6032": {
                Name2: "Signal green",
                RGB: {
                    R: 41,
                    G: 138,
                    B: 64
                }
            },
            "6033": {
                Name2: "Mint turquoise",
                RGB: {
                    R: 66,
                    G: 140,
                    B: 120
                }
            },
            "6034": {
                Name2: "Pastel turquoise",
                RGB: {
                    R: 125,
                    G: 189,
                    B: 181
                }
            },
            "7000": {
                Name2: "Squirrel grey",
                RGB: {
                    R: 115,
                    G: 133,
                    B: 145
                }
            },
            "7001": {
                Name2: "Silver grey",
                RGB: {
                    R: 135,
                    G: 148,
                    B: 166
                }
            },
            "7002": {
                Name2: "Olive grey",
                RGB: {
                    R: 122,
                    G: 117,
                    B: 97
                }
            },
            "7003": {
                Name2: "Moss grey",
                RGB: {
                    R: 112,
                    G: 112,
                    B: 97
                }
            },
            "7004": {
                Name2: "Signal grey",
                RGB: {
                    R: 156,
                    G: 156,
                    B: 166
                }
            },
            "7005": {
                Name2: "Mouse grey",
                RGB: {
                    R: 97,
                    G: 105,
                    B: 105
                }
            },
            "7006": {
                Name2: "Beige grey",
                RGB: {
                    R: 107,
                    G: 97,
                    B: 87
                }
            },
            "7008": {
                Name2: "Khaki grey",
                RGB: {
                    R: 105,
                    G: 84,
                    B: 56
                }
            },
            "7009": {
                Name2: "Green grey",
                RGB: {
                    R: 77,
                    G: 82,
                    B: 74
                }
            },
            "7010": {
                Name2: "Tarpaulin grey",
                RGB: {
                    R: 74,
                    G: 79,
                    B: 74
                }
            },
            "7011": {
                Name2: "Iron grey",
                RGB: {
                    R: 64,
                    G: 74,
                    B: 84
                }
            },
            "7012": {
                Name2: "Basalt grey",
                RGB: {
                    R: 74,
                    G: 84,
                    B: 89
                }
            },
            "7013": {
                Name2: "Brown grey",
                RGB: {
                    R: 71,
                    G: 66,
                    B: 56
                }
            },
            "7015": {
                Name2: "Slate grey",
                RGB: {
                    R: 61,
                    G: 66,
                    B: 82
                }
            },
            "7016": {
                Name2: "Anthracite grey",
                RGB: {
                    R: 38,
                    G: 46,
                    B: 56
                }
            },
            "7021": {
                Name2: "Black grey",
                RGB: {
                    R: 26,
                    G: 33,
                    B: 41
                }
            },
            "7022": {
                Name2: "Umbra grey",
                RGB: {
                    R: 61,
                    G: 61,
                    B: 59
                }
            },
            "7023": {
                Name2: "Concrete grey",
                RGB: {
                    R: 122,
                    G: 125,
                    B: 117
                }
            },
            "7024": {
                Name2: "Graphite grey",
                RGB: {
                    R: 48,
                    G: 56,
                    B: 69
                }
            },
            "7026": {
                Name2: "Granite grey",
                RGB: {
                    R: 38,
                    G: 51,
                    B: 56
                }
            },
            "7030": {
                Name2: "Stone grey",
                RGB: {
                    R: 145,
                    G: 143,
                    B: 135
                }
            },
            "7031": {
                Name2: "Blue grey",
                RGB: {
                    R: 77,
                    G: 92,
                    B: 107
                }
            },
            "7032": {
                Name2: "Pebble grey",
                RGB: {
                    R: 189,
                    G: 186,
                    B: 171
                }
            },
            "7033": {
                Name2: "Cement grey",
                RGB: {
                    R: 122,
                    G: 130,
                    B: 117
                }
            },
            "7034": {
                Name2: "Yellow grey",
                RGB: {
                    R: 143,
                    G: 135,
                    B: 112
                }
            },
            "7035": {
                Name2: "Light grey",
                RGB: {
                    R: 212,
                    G: 217,
                    B: 219
                }
            },
            "7036": {
                Name2: "Platinum grey",
                RGB: {
                    R: 158,
                    G: 150,
                    B: 156
                }
            },
            "7037": {
                Name2: "Dusty grey",
                RGB: {
                    R: 122,
                    G: 125,
                    B: 128
                }
            },
            "7038": {
                Name2: "Agate grey",
                RGB: {
                    R: 186,
                    G: 189,
                    B: 186
                }
            },
            "7039": {
                Name2: "Quartz grey",
                RGB: {
                    R: 97,
                    G: 94,
                    B: 89
                }
            },
            "7040": {
                Name2: "Window grey",
                RGB: {
                    R: 158,
                    G: 163,
                    B: 176
                }
            },
            "7042": {
                Name2: "Verkehrsgrau A",
                RGB: {
                    R: 143,
                    G: 150,
                    B: 153
                }
            },
            "7043": {
                Name2: "Verkehrsgrau B",
                RGB: {
                    R: 64,
                    G: 69,
                    B: 69
                }
            },
            "7044": {
                Name2: "Silk grey",
                RGB: {
                    R: 194,
                    G: 191,
                    B: 184
                }
            },
            "7045": {
                Name2: "Telegrau 1",
                RGB: {
                    R: 143,
                    G: 148,
                    B: 158
                }
            },
            "7046": {
                Name2: "Telegrau 2",
                RGB: {
                    R: 120,
                    G: 130,
                    B: 140
                }
            },
            "7047": {
                Name2: "Telegrau 4",
                RGB: {
                    R: 217,
                    G: 214,
                    B: 219
                }
            },
            "8000": {
                Name2: "Green brown",
                RGB: {
                    R: 125,
                    G: 92,
                    B: 56
                }
            },
            "8001": {
                Name2: "Ocher brown",
                RGB: {
                    R: 145,
                    G: 82,
                    B: 46
                }
            },
            "8002": {
                Name2: "Signal brown",
                RGB: {
                    R: 110,
                    G: 59,
                    B: 48
                }
            },
            "8003": {
                Name2: "Clay brown",
                RGB: {
                    R: 115,
                    G: 59,
                    B: 36
                }
            },
            "8004": {
                Name2: "Copper brown",
                RGB: {
                    R: 133,
                    G: 56,
                    B: 43
                }
            },
            "8007": {
                Name2: "Fawn brown",
                RGB: {
                    R: 94,
                    G: 51,
                    B: 31
                }
            },
            "8008": {
                Name2: "Olive brown",
                RGB: {
                    R: 99,
                    G: 61,
                    B: 36
                }
            },
            "8011": {
                Name2: "Nut brown",
                RGB: {
                    R: 71,
                    G: 38,
                    B: 28
                }
            },
            "8012": {
                Name2: "Red brown",
                RGB: {
                    R: 84,
                    G: 31,
                    B: 31
                }
            },
            "8014": {
                Name2: "Sepia brown",
                RGB: {
                    R: 56,
                    G: 38,
                    B: 28
                }
            },
            "8015": {
                Name2: "Chestnut brown",
                RGB: {
                    R: 77,
                    G: 31,
                    B: 28
                }
            },
            "8016": {
                Name2: "Mahogany brown",
                RGB: {
                    R: 61,
                    G: 31,
                    B: 28
                }
            },
            "8017": {
                Name2: "Chocolate brown",
                RGB: {
                    R: 46,
                    G: 28,
                    B: 28
                }
            },
            "8019": {
                Name2: "Grey brown",
                RGB: {
                    R: 43,
                    G: 38,
                    B: 41
                }
            },
            "8022": {
                Name2: "Black brown",
                RGB: {
                    R: 13,
                    G: 8,
                    B: 13
                }
            },
            "8023": {
                Name2: "Orange brown",
                RGB: {
                    R: 156,
                    G: 69,
                    B: 41
                }
            },
            "8024": {
                Name2: "Beige brown",
                RGB: {
                    R: 110,
                    G: 64,
                    B: 48
                }
            },
            "8025": {
                Name2: "Pale brown",
                RGB: {
                    R: 102,
                    G: 74,
                    B: 61
                }
            },
            "8028": {
                Name2: "Terra brown",
                RGB: {
                    R: 64,
                    G: 46,
                    B: 33
                }
            },
            "9001": {
                Name2: "Cream",
                RGB: {
                    R: 255,
                    G: 252,
                    B: 240
                }
            },
            "9002": {
                Name2: "Grey white",
                RGB: {
                    R: 240,
                    G: 237,
                    B: 230
                }
            },
            "9003": {
                Name2: "Signal white",
                RGB: {
                    R: 255,
                    G: 255,
                    B: 255
                }
            },
            "9004": {
                Name2: "Signal black",
                RGB: {
                    R: 28,
                    G: 28,
                    B: 33
                }
            },
            "9005": {
                Name2: "Jet black",
                RGB: {
                    R: 3,
                    G: 5,
                    B: 10
                }
            },
            "9006": {
                Name2: "White aluminium",
                RGB: {
                    R: 166,
                    G: 171,
                    B: 181
                }
            },
            "9007": {
                Name2: "Grey aluminium",
                RGB: {
                    R: 125,
                    G: 122,
                    B: 120
                }
            },
            "9010": {
                Name2: "Pure white",
                RGB: {
                    R: 250,
                    G: 255,
                    B: 255
                }
            },
            "9011": {
                Name2: "Graphite black",
                RGB: {
                    R: 13,
                    G: 18,
                    B: 26
                }
            },
            "9016": {
                Name2: "Traffic white",
                RGB: {
                    R: 252,
                    G: 255,
                    B: 255
                }
            },
            "9017": {
                Name2: "Traffic black",
                RGB: {
                    R: 20,
                    G: 23,
                    B: 28
                }
            },
            "9018": {
                Name2: "Papyrus white",
                RGB: {
                    R: 219,
                    G: 227,
                    B: 222
                }
            }
        });
        this.RAL.init = function () {
            var a;
            this.Data = this.SourceData;
            for (a in this.Data) {
                this.Data[a].Name = "RAL " + a;
                this.Data[a].HSV = I.getColorByRGB(this.Data[a].RGB);
                this.indexByHue(a)
            }
            this.Inited = true
        };
        this.update()
    };
    return {
        init: function (b) {
            var d, f;
            d = parseInt($.browser.version, 10);
            if (!($.browser.msie && d < 7)) {
                $("#csd3-jscheck").hide();
                z.Canvas = $(D.CanvasSelector);
                z.Canvas.fadeIn(1E3);
                z.LivePreview = $(b.LivePreview);
                z.Colorize = z.Canvas.add(z.LivePreview);
                A.Core.init();
                A.History.init();
                for (f in b.CtrlInserts) A[f].init(b.CtrlInserts[f]);
                j.init.trigger();
                b.customInit && b.customInit()
            }
        },
        broadcast: function (b, d) {
            j[b] && j[b].trigger(null, d)
        },
        getPalette: function () {
            return g
        }
    }
}();
$(function () {
    ColorSchemeDesigner.init({
        CtrlInserts: {
            ModelSelect: "#csd3-model-cover",
            ColorWheel: "#csd3-pane-wheel",
            HueVal: "#csd3-wheel",
            HueCompl: "#csd3-wheel",
            DistVal: "#csd3-wheel",
            RGBVal: "#csd3-wheel",
            RGBParts: "#csd3-wheel",
            VarPresets: "#csd3-pane-vars",
            SVSqrSlider: "#csd3-c1-cover",
            CSqrSlider: "#csd3-c1-cover",
            ManVarSqrSlider: "#csd3-c2-cover",
            SchemeInfo: "#csd3-pane-info",
            TabWheel: "#csd3-tabs-color",
            TabVars: "#csd3-tabs-color",
            TabInfo: "#csd3-tabs-color",
            TabC1: "#csd3-tabs-csv",
            TabC2: "#csd3-tabs-csv",
            VisionWarning: "#csd3-canvas",
            TabPreview0: "#csd3-tabs-preview",
            TabPreview1: "#csd3-tabs-preview",
            TabPreview2: "#csd3-tabs-preview",
            MenuHistory: null,
            MenuVision: null,
            Tooltips: null,
            ColorTooltips: null
        },
        LivePreview: "#csd3-preview-palette-canvas",
        customInit: function () {
            $("#csd3-preview-palette-canvas .cbox").click(function () {
                var J, r;
                J = $(this).attr("rel");
                r = J.split("-");
                r = r[0];
                ColorSchemeDesigner.broadcast("selMVcol", r);
                ColorSchemeDesigner.broadcast("selMVvar", J)
            });
            ColorSchemeDesigner.broadcast("loadSchemeByURL");
            ColorSchemeDesigner.broadcast("tabWheelClick")
        }
    });
    $("#csd3-menu").droppy({
        speed: 100,
        persist: 100
    });
    $("#csd3-menu a").not(".link").click(function (J) {
        J.preventDefault();
        $(this).blur()
    });
    $("#csd3-menu-undo").click(function () {
        ColorSchemeDesigner.broadcast("historyBack");
        return false
    });
    $("#csd3-menu-redo").click(function () {
        ColorSchemeDesigner.broadcast("historyFwd");
        return false
    });
    $("#csd3-menu-random-now").click(function () {
        ColorSchemeDesigner.broadcast("randomScheme");
        return false
    });
    $("#csd3-menu-random-set").click(function () {
        ColorSchemeDesigner.broadcast("randomPrefs");
        return false
    });
    $("#csd3-menu-convert-0").click(function () {
        ColorSchemeDesigner.broadcast("setConversion", 0);
        return false
    });
    $("#csd3-menu-convert-1").click(function () {
        ColorSchemeDesigner.broadcast("setConversion", 1);
        return false
    });
    $("#csd3-menu-convert-2").click(function () {
        ColorSchemeDesigner.broadcast("setConversion", 2);
        return false
    });
    $("#csd3-menu-convert-3").click(function () {
        ColorSchemeDesigner.broadcast("setConversion", 3);
        return false
    });
    $("#csd3-menu-export-img").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "img");
        return false
    });
    $("#csd3-menu-export-txt").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "txt");
        return false
    });
    $("#csd3-menu-export-html").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "html");
        return false
    });
    $("#csd3-menu-export-xml").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "xml");
        return false
    });
    $("#csd3-menu-export-aco").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "aco");
        return false
    });
    $("#csd3-menu-export-ase").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "ase");
        return false
    });
    $("#csd3-menu-export-gpl").click(function () {
        ColorSchemeDesigner.broadcast("setExport", "gpl");
        return false
    });
    $("#csd3-menu-tooltips").click(function () {
        ColorSchemeDesigner.broadcast("toggleTooltips");
        return false
    });
    $("#csd3-menu-about").click(function () {
        window.open(this.href);
        return false
    })
    $("#csd3-menu-web-safe-colors").click(function () {
        window.open(this.href);
        return false
    })
    $("#csd3-menu-html-colors").click(function () {
        window.open(this.href);
        return false
    })
    $("#csd3-menu-color-names").click(function () {
        window.open(this.href);
        return false
    })
    $("#csd3-muline-colors").click(function () {
        window.open(this.href);
        return false
    })
    $("#csd3-car-color-paint").click(function () {
        window.open(this.href);
        return false
    })
});